<!-- Table Section -->
<div class=" px-4 py-3 sm:px-6 lg:px-8  mx-auto"
    x-data="{
        statusFilter: @entangle('review_status') ,
        showModal: false,
        handleKeydown(event) {
            if (event.key === '/' || event.keyCode === 191) {
                event.preventDefault();
                this.openModal();
            }
            if (event.key === 'Escape' || event.keyCode === 27) {
                this.closeModal();
            }
        },
        openModal() {
            this.showModal = true;
            $nextTick(() => {
                $wire.set('project_search', '');
                $refs.searchInput?.focus();
            });
        },
        closeModal() {
            this.showModal = false;
            $wire.set('project_search', '');
        },
        search_project() {
            this.closeModal();
        } 
                
    }"

    @keydown.window="handleKeydown"


>
     
 
    

    <!-- Card -->
    <div class="flex flex-col">
        <div class="-m-1.5 overflow-x-auto">
            <div class="p-1.5 max-w-full w-full align-middle ">

 
                <!-- Header -->
                <div class="flex flex-col sm:flex-row justify-between items-center mb-2">
                    <div class="flex items-center">
                        {{-- Filter Review Status --}}
                    </div>

                    <!-- Filter Buttons -->
                    <div class="flex space-x-2 mt-3 sm:mt-0">
                        <!-- All -->
                        <button 
                            @click="statusFilter = 'all'; $wire.set('review_status', 'all')"
                            :class="statusFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-white text-slate-700 border'"
                            class="relative px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                        >
                            <span>All</span>
                            <span 
                                class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                                :class="statusFilter === 'all' ? 'bg-white text-slate-800' : 'bg-slate-100 text-slate-700'"
                                x-text="$wire.count_all"
                            ></span>
                        </button>

                        @if(Auth::user()->hasPermissionTo('system access admin'))
                        <button 
                            @click="statusFilter = 'on_que', $wire.set('document_status', 'on_que')"
                            :class="statusFilter === 'on_que' ? 'bg-slate-500 text-white' : 'bg-white text-slate-600 border border-slate-300'"
                            class="px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                        >
                            On Queue

                            <span 
                                class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                                :class="statusFilter === 'on_que' ? 'bg-white text-slate-800' : 'bg-slate-100 text-slate-700'"
                                x-text="$wire.count_on_que"
                            ></span>

                        </button>
                        @endif



                        @if(Auth::user()->hasPermissionTo('system access admin'))
                        <button 
                            @click="statusFilter = 'open_review', $wire.set('review_status', 'open_review')"
                            :class="statusFilter === 'open_review' ? 'bg-lime-500 text-white' : 'bg-white text-lime-600 border border-lime-300'"
                            class="px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                        >
                            Open Review

                            <span 
                                class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                                :class="statusFilter === 'open_review' ? 'bg-white text-lime-800' : 'bg-lime-100 text-lime-700'"
                                x-text="$wire.count_open_review"
                            ></span>

                        </button>
                        @endif

                        <button 
                            @click="statusFilter = 'changes_requested', $wire.set('review_status', 'changes_requested')"
                            :class="statusFilter === 'changes_requested' ? 'bg-violet-500 text-white' : 'bg-white text-violet-600 border border-violet-300'"
                            class="px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                        >
                            Changes Requested

                            <span 
                                class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                                :class="statusFilter === 'changes_requested' ? 'bg-white text-violet-800' : 'bg-violet-100 text-violet-700'"
                                x-text="$wire.count_changes_requested"
                            ></span>

                        </button>

                         <button 
                            @click="statusFilter = 'pending', $wire.set('review_status', 'pending')"
                            :class="statusFilter === 'pending' ? 'bg-blue-500 text-white' : 'bg-white text-blue-600 border border-blue-300'"
                            class="px-3 py-1 rounded-lg text-sm font-medium transition  flex items-center space-x-1"
                        >
                            Pending Review

                            <span 
                                class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                                :class="statusFilter === 'pending' ? 'bg-white text-blue-800' : 'bg-blue-100 text-blue-700'"
                                x-text="$wire.count_pending"
                            ></span>

                        </button>

                        {{-- <button 
                            @click="statusFilter = 'approved'"
                            :class="statusFilter === 'approved' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-600 border border-emerald-300'"
                            class="px-3 py-1 rounded-lg text-sm font-medium transition"
                        >
                            Approved
                        </button> --}}
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl shadow-sm  overflow-x-auto ">
                


                     <!-- Header -->
                    <div class="w-full   px-4 py-2 border-b border-gray-200 bg-white">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-y-2">
                            <!-- Title and Subtitle -->
                            <div>
                                <h2 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                                    {{ $title }}
                                    <span class="inline-flex justify-center items-center w-6 h-6 text-xs font-medium bg-black text-white rounded-full">
                                        {{ $project_documents_count ?? 0 }}
                                    </span>
                                </h2>
                                <p class="text-sm text-gray-500">{{ $subtitle }}</p>
                            </div>

                            <!-- Action Bar -->
                            <div class="flex  flex-wrap items-center gap-2 justify-start sm:justify-end mt-2 sm:mt-0">

                                <!-- Search -->
                                <input type="text" wire:model.live="search"
                                    class="min-w-[160px] px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500"
                                    placeholder="Search"> 

                                <select wire:model.live="document_status" class="min-w-[140px] text-sm py-1.5 px-2 border rounded-md">
                                    <option value="">Document Status</option>
                                    @foreach ($document_status_options as $key => $value)
                                        <option value="{{ $key }}">{{ $value }}</option>
                                    @endforeach
                                </select>

                                <select wire:model.live="document_type_id" class="min-w-[140px] text-sm py-1.5 px-2 border rounded-md">
                                    <option value="">Document Type</option>
                                    @foreach ($document_type_options as $key => $value)
                                        <option value="{{ $key }}">{{ $value }}</option>
                                    @endforeach
                                </select>

                                @if(  $route !== "project.project-document.index")
                                    <button
                                        
                                        @click="openModal()"
                                        type="button"
                                        @keydown.window="handleKeydown" 
                                        class="py-2 px-3 inline-flex min-w-12 items-center gap-x-2 border-2 border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50   "
                                    
                                        >
                                        
                                        {{ !empty($project->name) ? $project->name : "Search Project" }} 

                                        <svg class="shrink-0 size-[.8em]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
                                    </button>
                                @endif


                                <select wire:model.live="sort_by" class="min-w-[160px] text-sm py-1.5 px-2 border rounded-md">
                                    <option value="">Sort By</option>
                                    
                                    <option>Document Name A - Z</option>
                                    <option>Document Name Z - A</option>
                                    <option>Project Name A - Z</option>
                                    <option>Project Name Z - A</option>
                                    <!-- Add rest of the sort options -->
                                </select>

                                 

                                @if(!empty($project) && !empty($project->id))
                                <!-- Create Button -->
                                <a href="{{ route('project.project-document.create',['project' => $project->id]) }}"
                                wire:navigate
                                    class="text-sm px-3 py-1.5 rounded-md bg-yellow-500 text-white hover:bg-yellow-600">
                                    + New
                                </a>
                                @endif
 

                            </div>
                        </div>
                    </div>
                    <!-- End Header -->  





        
                    <!-- Table -->
                    <table class="w-full divide-y divide-gray-200 overflow-x-auto">
                        <thead class="bg-gray-50 ">
                        <tr>
                            
                            <th class=" w-4    px-3 py-3  ">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Actions
                                    </span>
                                </div>
                            </th>
                            
                            <th scope="col" class="px-2 py-3 text-start">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Document
                                    </span>
                                </div>
                            </th>


                            <th scope="col" class="px-2 py-3 text-start">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Project
                                    </span>
                                </div>
                            </th>

                            <th scope="col" class="px-2 py-3 text-start">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Review
                                    </span>
                                </div>
                            </th>


                            <th scope="col" class="px-2 py-3 text-start">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Submitted
                                    </span>
                                </div>
                            </th>
                            <th scope="col" class="px-2 py-3 text-start">
                                <div class="flex items-center gap-x-2">
                                    <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                    Last Updated
                                    </span>
                                </div>
                            </th>
    

                            

                            
                        </tr>
                        </thead>

                        <tbody class="divide-y divide-gray-200 ">

                            @if(!empty($project_documents) && count($project_documents) > 0)
                                @foreach ($project_documents as $project_document)
                                    <tr>

                                        <td class="w-fill text-nowrap align-top px-4 py-3   ">
                                            <div class="flex items-center justify-between space-x-2">
                                                <div class="flex items-center gap-1">

                                                    @if($route == "project-document.index.open-review" || 

                                                        $route == "project.project_documents.open" || 

                                                        $review_status == "open_review"
                                                        
                                                        )
                                                    <button 
                                                        onclick="confirm('Are you sure you want to open this project for review? If you proceed, you will be assigned as the official reviewer.') || event.stopImmediatePropagation()"
                                                        wire:click.prevent="open_review_project_document({{ $project_document->id }})"
                                                        type="button"
                                                        class="rounded-md bg-lime-500 px-2.5 py-1 text-xs font-medium text-white">
                                                        Review
                                                    </button>

                                                    @elseif($route == "project-document.index.review-pending" || $review_status == "pending")
                                                        <a 
                                                            href="{{ route('project-document.review',[
                                                                'project' => $project_document->project_id,
                                                                'project_document' => $project_document->id,
                                                            ]) }}"
                                                            
                                                            wire:navigate
                                                            class="rounded-md bg-blue-500 px-2.5 py-1 text-xs font-medium text-white">
                                                            Review
                                                        </a>
                                                    @else 
                                                    @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document list view'))

                                                    <a 
                                                        href="{{ route('project.project-document.show', ['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}"
                                                        wire:navigate
                                                        class="rounded-md bg-black px-2.5 py-1 text-xs font-medium text-white">
                                                        View
                                                    </a>
                                                    @endif
                                                    @endif
                                                    

                                                    <el-dropdown class="inline-block p-0">
                                                        <button class=" inline-flex rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-50">
                                                            
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4">
                                                                <circle cx="12" cy="5" r="2" />
                                                                <circle cx="12" cy="12" r="2" />
                                                                <circle cx="12" cy="19" r="2" />
                                                            </svg>

                                                        </button>

                                                        <el-menu anchor="bottom end" popover class="m-0 w-56 origin-top-right rounded-md bg-white p-0 shadow-lg outline outline-1 outline-black/5 transition [--anchor-gap:theme(spacing.2)] [transition-behavior:allow-discrete] data-[closed]:scale-95 data-[closed]:transform data-[closed]:opacity-0 data-[enter]:duration-100 data-[leave]:duration-75 data-[enter]:ease-out data-[leave]:ease-in">
                                                            <div class="py-1">
                                                                

                                                                @if($project_document->status !== "draft" && $project_document->status !== "on_que")
                                                                    @if(Auth::user()->can('system access global admin') 
                                                                    // || Auth::user()->can('project submit')
                                                                    || Auth::user()->can('system access admin')
                                                                    || Auth::user()->can('system access reviewer')
                                                                    )
                                                                        @if($project_document->allow_project_submission == false)

                                                                            @if($route == "project-document.index.open-review" || $review_status == "open_review")
                                                                            <!-- Submit Project Document -->
                                                                            <button
                                                                                
                                                                                onclick="confirm('Are you sure you want to open this project for review? If you proceed, you will be assigned as the official reviewer.') || event.stopImmediatePropagation()"
                                                                                wire:click.prevent="open_review_project_document({{ $project_document->id }})"
                                                                                type="button"
                                                                                class="block w-full px-4 py-2 text-left text-sm text-lime-700 focus:bg-lime-100 focus:text-lime-900 focus:outline-none"
                                                                                
                                                                            >   
                                                                                <div class="flex justify-between items-center">
                                                                                    <div>
                                                                                        Review
                                                                                    </div>

                                                                                    <div>
                                                                                        <x-svg.submit class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Review Project" />
                                                                                    </div>
                                                                                </div>

                                                                                
                                                                            </button>

                                                                            @elseif($route == "project-document.index.review-pending" || $review_status == "pending")
                                                                            <a
                                                                                
                                                                                href="{{ route('project-document.review',[
                                                                                    'project' => $project_document->project_id,
                                                                                    'project_document' => $project_document->id,
                                                                                ]) }}"
                                                                                
                                                                                wire:navigate
                                                                                class="block w-full px-4 py-2 text-left text-sm text-blue-700 focus:bg-blue-100 focus:text-blue-900 focus:outline-none"
                                                                                
                                                                            >   
                                                                                <div class="flex justify-between items-center">
                                                                                    <div>
                                                                                        Review
                                                                                    </div>

                                                                                    <div>
                                                                                        <x-svg.submit class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Review Project" />
                                                                                    </div>
                                                                                </div>

                                                                                
                                                                            </a>
                                                                            @endif

                                                                        @endif
                                                                    @endif
                                                                @else
                                                                    @if(Auth::user()->can('system access global admin') 
                                                                    // || Auth::user()->can('project submit')
                                                                    || Auth::user()->can('system access admin')
                                                                    )
                                                                        @if($project_document->allow_project_submission == false)
                                                                        <!-- Submit Project Document -->
                                                                        <button
                                                                            
                                                                            onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
        
                                                                            wire:click.prevent="force_submit_project_document({{ $project_document->id }})"
                                                                            type="button"
                                                                            class="block w-full px-4 py-2 text-left text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                            
                                                                        >   
                                                                            <div class="flex justify-between items-center">
                                                                                <div>
                                                                                    Force Submit
                                                                                </div>

                                                                                <div>
                                                                                    <x-svg.submit class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Force Submit" />
                                                                                </div>
                                                                            </div>

                                                                            
                                                                        </button>
                                                                        @endif
                                                                    @endif
                                                                    

                                                                
                                                                    @if(Auth::user()->can('system access global admin') || Auth::user()->can('system access admin') || Auth::user()->can('project submit'))
                                                                        @if($project_document->allow_project_submission == true)
                                                                        <!-- Submit Project Document -->
                                                                        <button
                                                                            {{ $project_document->allow_project_submission == true ? '' : 'disabled' }}
                                                                            onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
        
                                                                            wire:click.prevent="submit_project_document({{ $project_document->id }})"
                                                                            type="button"
                                                                            class="block w-full px-4 py-2 text-left text-sm  
                                                                            
                                                                            {{ $project_document->allow_project_submission == true ? 'text-gray-700' : 'text-gray-300' }}
                                                                            
                                                                            focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                        >   
                                                                            <div class="flex justify-between items-center">
                                                                                <div>
                                                                                    Submit
                                                                                </div>

                                                                                <div>
                                                                                    <x-svg.submit class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Submit" />
                                                                                </div>
                                                                            </div>

                                                                            
                                                                        </button>
                                                                        @endif
                                                                    @endif
                                                                @endif


                                                                    

                                                                @if(Auth::user()->can('system access global admin') || 
                                                                // Auth::user()->can('project reviewer list view')
                                                                 Auth::user()->can('system access admin')
                                                                )
                                                                    <a 
                                                                    href="{{ route('project.document.reviewer.index', ['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}"
                                                                    wire:navigate
                                                                    class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                        <div class="flex justify-between items-center">
                                                                            <div>
                                                                                Document Reviewers
                                                                            </div>

                                                                            <div>
                                                                                <x-svg.reviewer class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Document Reviewers" />
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                @endif



                                                                @if(Auth::user()->can('system access global admin') || Auth::user()->can('project view'))
                                                                    <a 
                                                                    href="{{ route('project.project-document.show', ['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}"
                                                                    wire:navigate
                                                                    class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                        <div class="flex justify-between items-center">
                                                                            <div>
                                                                                View
                                                                            </div>

                                                                            <div>
                                                                                <x-svg.display class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                @endif
    
                                                            
                                                                
                                                                @if(Auth::user()->can('system access global admin') || Auth::user()->can('project edit'))
                                                                    <a 
                                                                    href="{{ route('project.project_document.edit_attachments',['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}"
                                                                    wire:navigate 
                                                                    class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                        <div class="flex justify-between items-center">
                                                                            <div>
                                                                                Edit
                                                                            </div>

                                                                            <div>
                                                                                <x-svg.edit class="text-blue-600 hover:text-blue-700 size-4 shrink-0" title="Edit" />
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                @endif
                                                                    
                                                                @if(Auth::user()->can('system access global admin') || Auth::user()->can('project delete'))
                                                                    <!-- Force Delete-->
                                                                    <button
                                                                        onclick="confirm('Are you sure, you want to delete this record?') || event.stopImmediatePropagation()"
                                                                        wire:click.prevent="delete({{ $project_document->id }})"
                                                                        type="button"
                                                                        class="block w-full px-4 py-2 text-left text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                    >   
                                                                        <div class="flex justify-between items-center">
                                                                            <div>
                                                                                Delete
                                                                            </div>

                                                                            <div>
                                                                                <x-svg.delete class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Delete" />
                                                                            </div>
                                                                        </div>

                                                                        
                                                                    </button>
                                                                @endif

                                                            </div>
                                                        </el-menu>
                                                    </el-dropdown>
                    

                                                </div>
                                            </div>
                                        </td>

                                        <td class=" text-nowrap align-top whitespace-nowrap px-4 py-3 text-sm text-gray-700">

                                            
                                        <div class="flex items-center gap-2">
                                            <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 ring-1 ring-slate-200">
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M4 7a2 2 0 0 1 2-2h7l5 5v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M13 5v4h4"/></svg>
                                            </div>
                                            <div>
                                                <a  href="{{ route('project.project-document.show', ['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}"
                                                    wire:navigate 
                                                    class="font-medium text-slate-900 hover:underline">
                                                    {{ $project_document->document_type ? $project_document->document_type->name : '' }}
                                                </a>
                                                <div class="text-xs text-slate-500">
                                                    RC#: {{ $project_document->rc_number ? $project_document->rc_number : 'NOT SET' }}
                                                </div>

                                                <div class="text-xs text-slate-500">
                                                    {{ $project_document->project_attachments ? $project_document->project_attachments->count().' attachments found' : 'No attachments found' }}
                                                </div>
                                                {{-- <div>
                                                    @include('livewire.partials.status-badge',['status' => $project_document['status']])
                                                </div> --}}
                                            </div>

                                            {{-- <div class="flex items-center gap-1">
                                                <a  href="{{ route('project.project_document', ['project' => $project_document->project->id, 'project_document' => $project_document->id]) }}" 
                                                    wire:navigate 
                                                    class="rounded-md border border-slate-200 px-2.5 py-1 text-xs">
                                                    View
                                                </a> 
                                            </div> --}}

                                        </div>
                                                
                                                

                                        </td>
                                        
                                        <td class="px-4 py-2 align-top">
                                            <a href="{{ route('project.show',['project' => $project_document->project->id]) }}" wire:navigate class="font-medium text-slate-800 hover:underline">
                                                {{ $project_document->project->name }}
                                            </a>
                                            <div class="text-xs text-slate-500">
                                                {{ $project_document->project->project_documents ? $project_document->project->project_documents->count().' documents found' : 'No documents found' }}
                                            </div>
                                        </td>
                                        {{-- <td class="max-w-32 text-nowrap align-top px-4 py-3 ">
                                            <div class="space-y-1">
                                                <p class="text-sm font-semibold text-gray-900">{{ $project_document->project->name }}</p>
                                                <p class="text-sm text-gray-500">{{ $project_document->project->federal_agency }}</p>
                                                <p class="text-sm font-semibold text-green-700">{{ $project_document->project->type }}</p>
                                            </div>
                                        </td>

                                        
                                        <td class="align-top  py-3 text-slate-700"> 
                                            {{ $project_document->project->type }}  
                                        </td>
                                        
                                        
                                        <td class="px-4 py-2 text-slate-600">PDF</td> --}}

                                        {{--  review --}}
                                        @if(
                                        ($project_document->status !== "draft" && ($route == "project.index.open-review" || $route == "project.project_documents.open")) || 
                                        $project_document->status !== "draft"
                                        )
                                            {{-- <livewire:partials.table-reviewer-status-badge  
                                                :status="$project_document->status"
                                                :project-document="$project_document"
                                            /> --}}
                                            @php    
                                                $config = $this->returnStatusConfig($project_document->status); 
                                                $reviewerName = $this->returnReviewerName($project_document);
                                                $slotType = $this->returnSlotData($project_document,'slot_type');
                                                $slotRole = $this->returnSlotData($project_document,'slot_role');
                                                $reviewStatus = $this->returnReviewStatus($project_document);

                                                

                                                $dueAtText = $this->returnDueDate($project_document, 'dueAtText');
                                                $dueAtDiff = $this->returnDueDate($project_document, 'dueAtDiff');
                                                
                                                
                                                $flags = $this->returnReviewFlagsStatus($project_document);
                                            @endphp


                                            <td class="px-4 py-2 align-top"
                                                x-data="{ 

                                                    roleColors: {
                                                        'global admin': 'bg-red-100 text-red-700 ring-red-200',
                                                        'admin':        'bg-amber-100 text-amber-800 ring-amber-200',
                                                        'reviewer':     'bg-sky-100 text-sky-700 ring-sky-200',
                                                        'user':         'bg-slate-100 text-slate-700 ring-slate-200',
                                                        '__none':       'bg-zinc-100 text-zinc-700 ring-zinc-200',
                                                    },

                                                    badgeCls(role){
                                                        const key = (role || '').toLowerCase();
                                                        const base = 'px-1.5 py-0.5 rounded-md text-xs ring-1';
                                                        return `${base} ${(this.roleColors[key] ?? this.roleColors['__none'])}`;
                                                    }, 
                                                }"  

                                                >
                                                <!-- Status badge -->
                                                <div class="mb-1">
                                                    <span class="inline-flex items-center gap-1 rounded-full {{ $config['bg'] }} px-2 py-0.5 text-[11px] font-semibold {{ $config['text'] }} ring-1 ring-inset {{ $config['ring'] }}">
                                                        {{ $config['label'] }}
                                                    </span>
                                                </div>


                                                @if($project_document->status != "approved")
                                                <!-- Reviewer block -->
                                                <div class="space-y-1 text-[11px] leading-4 text-slate-600">
                                                    <div class="flex items-center gap-1">
                                                        <!-- Eye/user icon -->
                                                        <svg class="size-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12Z" />
                                                            <circle cx="12" cy="12" r="3" />
                                                        </svg>
                                                        <span class="font-medium text-slate-700">Reviewer:</span>
                                                        <span class="truncate">{{ $reviewerName }}</span>
                                                        
                                                            @if($slotType === 'person')

                                                                @php 
                                                                    // dd($project_document->user_id);

                                                                    $project_reviewer = $project_document->getCurrentReviewerByProjectDocument(); // get the current reviewer


                                                                    $roles = $this->getUserRoles($project_reviewer->user_id);

                                                                    // dd($roles);
                                                                @endphp
 
                                                                {{-- <span class="ml-1 rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] text-slate-700">{{ $slotRole }}</span> --}}
                                                                <!-- If this row has a userId (person or claimed open slot), show that user's roles -->
                                                                @if(!empty($roles))
                                                                    <div class="flex flex-wrap items-center gap-1.5">
                                                                        @foreach ($roles as $role)
                                                                            <span :class="badgeCls('{{ $role }}')"  >{{ $role }}</span>
                                                                        @endforeach
                                                                    </div>
                                                                @else
                                                                    <span :class="badgeCls('')">No role</span>
                                                                @endif


                                                            @elseif(($slotType === 'open'))

                                                                @if($slotType === 'open' && empty($project_document->user_id)) 
                                                                    <span class="ml-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[10px] text-amber-700">Open</span>
                                                                    @php 
                                                                        // dd($project_document->user_id);

                                                                        $project_reviewer = $project_document->getCurrentReviewerByProjectDocument(); // get the current reviewer


                                                                        $roles = $this->getUserRoles($project_reviewer->user_id);

                                                                        // dd($roles);
                                                                    @endphp
                                                                    {{-- <span class="ml-1 rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] text-slate-700">{{ $slotRole }}</span> --}}
                                                                    <!-- If this row has a userId (person or claimed open slot), show that user's roles -->
                                                                    @if(!empty($roles))
                                                                        <div class="flex flex-wrap items-center gap-1.5">
                                                                            @foreach ($roles as $role)
                                                                                <span :class="badgeCls('{{ $role }}')"  >{{ $role }}</span>
                                                                            @endforeach
                                                                        </div>
                                                                    @else
                                                                        <span :class="badgeCls('')">No role</span>
                                                                    @endif

                                                                    
                                                                @elseif($slotType === 'open' && !empty($project_document->user_id))
                                                                    <span class="ml-1 rounded border border-sky-200 bg-sky-50 px-1.5 py-0.5 text-[10px] text-sky-700">Claimed</span>
                                                                @else
                                                                    <span class="ml-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[10px] text-amber-700">Open</span>
                                                                @endif
                                                            @endif
                                                         


                                                    </div>

                                                    @if(!empty($reviewStatus))
                                                    <div class="flex items-center gap-1">
                                                        <svg class="size-3.5 shrink-0 text-slate-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                            <path d="M10 18a8 8 0 100-16 8 8 0 000 16Zm3.707-9.707a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 10-1.414 1.414L9 13.414l4.707-4.707Z"/>
                                                        </svg>
                                                        <span class="font-medium text-slate-700">Review status:</span>
                                                        <span class="uppercase tracking-wide">{{ $reviewStatus }}</span>
                                                    </div>
                                                    @endif

                                                    <div class="flex items-center gap-1">
                                                        <svg class="size-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3M3.5 9h17M5 20h14a2 2 0 0 0 2-2v-9H3v9a2 2 0 0 0 2 2Z"/>
                                                        </svg>
                                                        <span class="font-medium text-slate-700">
                                                            {{ $project_document->allow_project_submission == true ? 'Response due' : 'Review due'}}:
                                                        </span>
                                                        @if($dueAtText)
                                                            <span>{{ $dueAtText }}</span>
                                                            <span class="text-slate-400">({{ $dueAtDiff }})</span>
                                                        @else
                                                            <span class="italic text-slate-400">No due date</span>
                                                        @endif
                                                    </div>

                                                    <!-- Flags -->
                                                    <div class="flex flex-wrap items-center gap-1.5 pt-0.5">
                                                        @php
                                                            $flagLabels = [
                                                                'requires_project_update' => 'Project update',
                                                                // 'requires_document_update' => 'Document update',
                                                                'requires_attachment_update' => 'Attachment update',
                                                            ];
                                                        @endphp

                                                        @foreach($flagLabels as $key => $label)
                                                            @if($flags[$key] ?? false)
                                                                <span class="inline-flex items-center gap-1 rounded-md bg-amber-50 px-1.5 py-0.5 ring-1 ring-amber-200 text-[10px] font-medium text-amber-700">
                                                                    <svg class="size-3" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a8 8 0 100 16 8 8 0 000-16Zm.75 4a.75.75 0 00-1.5 0v5.25c0 .414.336.75.75.75h3.5a.75.75 0 000-1.5h-2.75V6Z"/></svg>
                                                                    {{ $label }}
                                                                </span>
                                                            @else
                                                                <span class="inline-flex items-center gap-1 rounded-md bg-slate-50 px-1.5 py-0.5 ring-1 ring-slate-200 text-[10px] text-slate-500">
                                                                    <svg class="size-3" viewBox="0 0 20 20" fill="currentColor"><path d="M10 18a8 8 0 100-16 8 8 0 000 16Zm-1-5 5-5-1.414-1.414L9 10.172 7.414 8.586 6 10l3 3Z"/></svg>
                                                                    {{ $label }}
                                                                </span>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                </div>
                                                @elseif($project_document->status == "approved")
                                                

                                                <!-- Reviewer block -->
                                                <div class="space-y-1 text-[11px] leading-4 text-slate-600">
                                                    <div class="flex items-center gap-1">
                                                        
                                                        <span class="font-medium text-slate-700">All reviewers had approved the project document</span> 

                                                    </div>
                                                </div>
                                                @endif

                                            </td>

    



                                        @else

                                            @php    
                                                $config = $this->returnStatusConfig($project_document->status);  
                                            @endphp
                                            {{-- <livewire:partials.table-status-badge   
                                                    :status="$project_document->status"
                                                />   --}}

                                            <td class="px-4 py-2 align-top">
                                                <span class="rounded-full {{ $config['bg'] }} px-2 py-0.5 text-[11px] font-semibold {{ $config['text'] }} ring-1 ring-inset {{ $config['ring'] }}">
                                                    {{ $config['label'] }}
                                                </span>
                                            </td>

                                        @endif                          


                                        <td class="px-4 py-2 text-slate-600 align-top">
                                        
                                            @php    
                                                $formatted = $this->returnFormattedDatetime($project_document->last_submitted_at);
                                                $userName = $this->returnFormattedUser($project_document->last_submitted_by);
                                            @endphp

                                            @if($formatted)
                                                <div class="text-sm">{{ $formatted }}</div>
                                                <div class="text-xs text-slate-400">
                                                    Submitted by {{ $userName }}
                                                </div>
                                            @else
                                                <div class="text-sm text-slate-400 italic">No data yet</div>
                                            @endif
                                        </td>


                                        <td class="px-4 py-2 text-slate-600 align-top">
                                        
                                            @php    
                                                $formatted = $this->returnFormattedDatetime($project_document->updated_at);
                                                $userName = $this->returnFormattedUser($project_document->updated_by);
                                            @endphp

                                            @if($formatted)
                                                <div class="text-sm">{{ $formatted }}</div>
                                                <div class="text-xs text-slate-400">
                                                    Updated by {{ $userName }}
                                                </div>
                                            @else
                                                <div class="text-sm text-slate-400 italic">No data yet</div>
                                            @endif
                                        </td>


                                        
    

                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <th scope="col" colspan="6" class="px-6 py-3 text-start">
                                        <div class="flex items-center gap-x-2">
                                            <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                            No records found
                                            </span>
                                        </div>
                                    </th>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                    <!-- End Table -->

                    <!-- Footer -->
                    <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-t border-gray-200 ">
                        {{ $project_documents->links() }}

                        <div class="inline-flex items-center gap-x-2">
                            <p class="text-sm text-gray-600 ">
                            Showing:
                            </p>
                            <div class="max-w-sm space-y-3">
                            <select wire:model.live="record_count" class="py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                                <option>10</option>
                                <option>25</option>
                                <option>50</option>
                                <option>100</option>
                                <option>200</option>
                            </select>
                            </div>
                            <p class="text-sm text-gray-600 ">
                                {{ count($project_documents) > 0 ? 'of '.$project_documents->total()  : '' }}
                            </p>
                        </div>


                    </div>
                    <!-- End Footer -->


                </div>
            </div>
        </div>
    </div>
    <!-- End Card -->

    

    <!-- Schedule modal-->
    @teleport('body')
        <div x-show="showModal" x-trap="showModal" wire:teleport="body"  class="relative z-50 " aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

            <!-- <div class="fixed inset-0 z-10 w-screen overflow-y-auto py-10"> -->
            <div class="fixed inset-0 z-50 w-screen overflow-y-auto py-10">
                <div class="flex justify-center p-4 sm:p-0">
                    <div
                        class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                        <div @click.outside="showModal = false, $wire.set('project_search','')" class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4"
                        wire:key="project-search-modal"
                        >
                            <div class="w-full px-1 pt-1" x-data="{
                                searchPosts(event) {
                                    document.getElementById('searchInput').focus();
                                    event.preventDefault();
                                }
                            }">
                                <form action="" autocomplete="off" @submit.prevent>
                                    <input
                                    x-ref="searchInput"
                                    autocomplete="off"
                                    wire:model.live.throttle.500ms="project_search"
                                    type="text" 
                                    id="searchInput"
                                    name="searchInput"
                                    class="block w-full flex-1 py-2 px-3 mt-2 outline-none border-none rounded-md bg-slate-100"
                                    placeholder="Search for project name ..." @keydown.slash.window="searchPosts" />
                                </form>
                                <div class="mt-2 w-full overflow-hidden rounded-md bg-white">

                                    
                                        @if(!empty($results) && count($results) > 0)
                                            <div class=" py-2 px-3 border-b border-slate-200 text-sm font-medium text-slate-500">

                                                All Projects <strong>(Click to select a project)</strong>

                                            </div>

                                            @foreach ($results as $result)
                                                <div class="cursor-pointer py-2 px-3 hover:bg-slate-100 bg-white border border-gray-200 shadow-sm rounded-xl mb-1"
                                                wire:click="search_project('{{  $result->id }}')"
                                                @click="showModal = false"
                                                >
                                                    <p class="text-sm font-medium text-gray-600 cursor-pointer flex items-center gap-3">
                                                        

                                                        <div class="max-w-full text-wrap ">
                                                            <div class="px-2 py-2   text-wrap">
                                                                 
 
 
                                                                <span class="text-sm text-gray-600 ">
                                                                    <strong>{{ $result->name }}</strong>
                                                                    <hr>
                                                                    <span class="text-blue-500">{{ $result->project_documents->count() ?? 0 }} documents</span> 
                                                                    <hr>
                                                                    {{ $result->federal_agency }}
                                                                    <hr>
                                                                    {{ $result->rc_number }}
                                                                    <hr>
                                                                    {{ $result->location }}
                                                                </span> 
 
                                                                     

                                                            </div>
                                                        </div>

                                                        

                                                        <div class="max-w-full size-auto whitespace-nowrap  ">
                                                            <div class="px-2 py-2   max-h-52 text-wrap overflow-auto">
                                                                <span class="text-sm text-gray-600  ">
                                                                    {{ $result->description ? $result->description : '' }}
                                                                </span>
                                                            </div>
                                                        </div>

                                                    </p>
                                                </div>
                                            @endforeach

                                        @else
                                            <div class=" py-2 px-3 border-b border-slate-200 text-sm font-medium text-slate-500">

                                                <div class="mb-2 bg-red-50 border-s-4 border-red-500 p-4 " role="alert" tabindex="-1" aria-labelledby="hs-bordered-red-style-label">
                                                    <div class="flex">
                                                        <div class="shrink-0">
                                                            <!-- Icon -->
                                                            <span class="inline-flex justify-center items-center size-8 rounded-full border-4 border-red-100 bg-red-200 text-red-800 ">
                                                                <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                    <path d="M18 6 6 18"></path>
                                                                    <path d="m6 6 12 12"></path>
                                                                </svg>
                                                            </span>
                                                            <!-- End Icon -->
                                                        </div>
                                                        <div class="ms-3">
                                                            <h3 id="hs-bordered-red-style-label" class="text-gray-800 font-semibold ">
                                                               Project not found
                                                            </h3>
                                                            <p class="text-sm text-gray-700 ">

                                                               Search for name, description, agency or related data
                                                            </p>
                                                        </div>



                                                    </div>
                                                </div>



                                            </div>
                                        @endif

    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endteleport
    <!-- ./ Schedule modal-->



  
    <!--  Loaders -->
        {{-- wire:target="table"   --}}
        <div wire:loading 
            class="p-0 m-0"
            style="padding: 0; margin: 0;">
            <div class="absolute right-4 top-4 z-50 inline-flex items-center gap-2 px-4 py-3 rounded-md text-sm text-white bg-blue-600 border border-blue-700 shadow-md animate-pulse mb-4 mx-3">
                <div>   
                    <svg class="h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                    </svg>
                </div>
                <div>
                    Loading lists, please wait...
                </div> 
            </div>
        </div>

        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>

        {{-- wire:target="delete"   --}}
        <div wire:loading  wire:target="delete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>
        


        

        {{-- wire:target="executeForceDelete"   --}}
        <div wire:loading  wire:target="executeForceDelete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>


        
        {{-- wire:target="executeRecover"   --}}
        <div wire:loading  wire:target="executeRecover"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Recovering record...
                    </div>
                </div>
            </div>

            
        </div>



    <!-- ./  Loaders -->


</div>
<!-- End Table Section -->

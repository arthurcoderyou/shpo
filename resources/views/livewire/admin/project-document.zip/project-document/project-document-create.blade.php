<!-- Card Section -->
<div   class="  px-4 py-6 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">

    
    
    <form class=" col-span-12 " wire:submit="save">
         
        <div class="bg-white rounded-2xl border border-slate-200 p-6 mb-6 space-y-6">
                

            <div class="grid grid-cols-12 gap-x-2  " id="add_project_document">

                @if(!empty($documentTypes) && count($documentTypes) > 0)
                    <div class="space-y-2 col-span-12     ">

                        <div class="space-y-2 col-span-12 sm:col-span-4  ">
                            <label for="type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                                Add New Document
                            </label>
                            <select
                                autofocus
                                class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  "
                                wire:model.live="document_type_id"
                                
                                >
                                <option value="">Select Document Type</option>
                                @foreach($documentTypes as $type)
                                    <option value="{{ $type->id }}">{{ $type->name }}</option>
                                @endforeach 

                            </select>


                            @error('document_type_id')
                                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                            @enderror 
                            
                        </div>




                        {{-- <div class="space-y-2 col-span-12 sm:col-span-4  "> 
                            <x-ui.input 
                                id="applicant"
                                name="applicant"
                                type="text"
                                wire:model.live="applicant"   
                                label="Applicant"
                                required  
                                placeholder="Enter applicant" 
                                :error="$errors->first('applicant')"

                                displayTooltip
                                position="top"
                                tooltipText="Please enter the applicant of the document." 
 
                            />

                        </div>


                        <div class="space-y-2 col-span-12 sm:col-span-4  "> 
                            <x-ui.input 
                                id="document_from"
                                name="document_from"
                                type="text"
                                wire:model.live="document_from"   
                                label="Document From"
                                required  
                                placeholder="Enter document source" 
                                :error="$errors->first('document_from')"

                                displayTooltip
                                position="top"
                                tooltipText="Please enter the source of the document." 
 
                            />

                        </div>

                        <div class="space-y-2 col-span-12 sm:col-span-4  "> 
                            <x-ui.input 
                                id="company"
                                name="company"
                                type="text"
                                wire:model.live="company"   
                                label="Company"
                                required  
                                placeholder="Enter company" 
                                :error="$errors->first('company')"

                                displayTooltip
                                position="top"
                                tooltipText="Please enter the company of the document." 
 
                            />

                        </div> --}}

 



                        <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Document Attachments
                        </label>

                        <livewire:dropzone
                            wire:model="attachments"
                            :rules="['file', 'mimes:png,jpeg,jpg,pdf,docx,xlsx,csv,txt,zip,mp4', 'max:20480']"
                            :multiple="true" />

                        {{-- <div class="col-span-12 sm:col-span-4">
                            <div class="w-full">
                                <x-filepond::upload wire:model="files" multiple /> 
                            </div>
                            

                        </div> --}}

                        @error('attachments')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror 

                    </div>

                @else


                    <div class="space-y-2 col-span-12     ">
 
                        <label   class="inline-block text-sm font-medium text-gray-800 mt-2.5  text-center">
                            All Document types had been added to the project
                        </label>
                             
                             

                    </div>



                @endif


                


            </div>
            <!-- End Grid -->





            @if(Auth::user()->hasRole('User')) 
            <!-- End Grid -->
            <p class="text-sm text-gray-600 mt-2">{{ !empty($reviewer_due_date) ? 'Expect to get a review at '.\Carbon\Carbon::parse($reviewer_due_date)->format('d M, h:i A') : '' }}</p>
            @endif

            <div class="mt-5 flex justify-center gap-x-2">

                

                <a href="{{ route('project.show',['project' => $project->id]) }}" 
                    wire:navigate
                    class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:bg-red-700 disabled:opacity-50 disabled:pointer-events-none">
                    Cancel
                </a>


                @if(!empty($documentTypes) && count($documentTypes) > 0)
                <button type="submit" class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                Save
                </button>
                @endif
                
                {{-- @if( Auth::user()->can('system access global admin') || Auth::user()->can('project submit') )
                <button {{ $project->allow_project_submission ? '' : 'disabled' }} type="button"
                    onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
                    wire:click.prevent="submit_project({{ $project_id }})"
                    
                    class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                    Submit
                </button> 
                @endif --}}


            </div>

        </div>

        
    </form>

   

    <!--  Loaders -->
         

        {{-- wire:target="save"   --}}
        <div wire:loading  wire:target="save"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Saving record...
                    </div>
                </div>
            </div>

            
        </div>


        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>

    <!--  ./ Loaders -->


    <div wire:loading  wire:target="delete"
    
    >
        <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
            <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                </svg>
                <div class="text-sm font-medium">
                    Deleting record...
                </div>
            </div>
        </div>

        
    </div>



         

</div>
<!-- End Card Section -->

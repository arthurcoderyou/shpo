<!-- Card Section -->
<div id="project-wrapper" data-project-id="{{ $project->id }}" class="max-w-[85rem] px-4 py-6 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
    
    {{-- The whole world belongs to you. --}}
    {{-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places"></script> --}}
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places&callback=initMap"
        async
        defer>
    </script>

    {{-- <div wire:loading class="loading-overlay"> --}}
        {{-- <div wire:loading style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
            <div></div>
            <div></div>
        </div> --}}
    {{-- </div> --}}
    
    <form class=" col-span-12 " wire:submit="save">
        <!-- Card -->
        <div class="bg-white rounded-xl shadow ">


            <div class="  p-4">
                <div class="bg-white rounded-2xl shadow p-6 mb-6 space-y-6">
                    {{-- <div class="sm:col-span-12">
                        <h2 class="text-lg font-semibold text-gray-800 ">
                            Edit project: 
                            <a href="{{ route('project.show',['project' => $project->id]) }}"
                            class="inline-block hover:underline hover:text-blue-500 text-sky-500 ">
                                {{ $project->name }}
                            </a> 
                        </h2>
                    </div> --}}

                    <!-- Left: Main Info -->
                    <div class="flex-1 min-w-[300px] space-y-2">
                        <h1 class="text-2xl font-semibold text-sky-800">
                            {{-- <span class="text-gray-500">Document:</span>  --}}
                            <span class="text-gray-500">Add New Project Document for:</span> <a href="{{ route('project.show',['project' => $project->id]) }}">{{ $project->name }}</a> 
                        </h1>
                        <div class="flex gap-x-2">

                            <!-- Edit -->
                            <a href="{{ route('project.show',['project' => $project->id]) }}" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border  bg-sky-500 text-white hover:bg-sky-700 focus:outline-hidden focus:border-sky-400  disabled:opacity-50 disabled:pointer-events-none">
                                View
                            </a>
                            <!-- Edit -->


                            <!-- Activity Logs -->
                            <a href="#discussion" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-500 text-gray-500 hover:border-gray-400 hover:text-gray-400 focus:outline-hidden focus:border-gray-400 focus:text-gray-400 disabled:opacity-50 disabled:pointer-events-none">
                                Discussion
                            </a>
                            <!-- Activity Logs -->


                            <!-- Activity Logs -->
                            <a href="#project_logs" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-teal-500 text-teal-500 hover:border-teal-400 hover:text-teal-400 focus:outline-hidden focus:border-teal-400 focus:text-teal-400 disabled:opacity-50 disabled:pointer-events-none">
                                Logs
                            </a>
                            <!-- Activity Logs -->
                        </div>

                    </div>


                    <!-- End Col -->



                    <!-- Project Documents List -->
                    <div class="space-y-2">
                        <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Project Documents
                        </label>

                        @if(!empty($project->project_documents) && $project->project_documents->count())
                            <ul class="divide-y divide-gray-200 border border-gray-200 rounded-lg overflow-hidden bg-white">
                                @foreach ($project->project_documents as $project_document)
                                    <li class="px-4 py-4 sm:px-6 hover:bg-gray-50 transition flex items-start justify-between">
                                        <div>
                                            <p class="text-base font-semibold text-gray-800">
                                                {{ $project_document->document_type->name }}
                                            </p>
                                            <p class="text-sm text-gray-600">
                                                {{ $project_document->project_attachments->count() }} attachment{{ $project_document->project_attachments->count() !== 1 ? 's' : '' }} found
                                            </p>
                                            <p class="text-xs text-gray-500 mt-1">
                                                Last updated {{ $project_document->updated_at->diffForHumans() }}
                                            </p>
                                        </div>  

                                        <div class="flex flex-col items-end gap-1 text-sm whitespace-nowrap">
                                            <a href="{{ route('project.project_document', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                class="text-gray-600 hover:underline hover:text-gray-800 flex items-center gap-x-1">
                                                View
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </a>


                                            <a href="{{ route('project.project_document', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                            class="text-blue-600 hover:underline hover:text-blue-800 flex items-center gap-x-1">
                                                Update
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </a>
                                            {{-- <button type="button"
                                                onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()"
                                                wire:click.prevent="delete({{ $project_document->id }})"
                                                class="text-red-600 hover:underline hover:text-red-800 flex items-center gap-x-1">
                                                Delete
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </button> --}}
                                        </div>
                                    </li>
                                @endforeach
                            </ul>
                        @else
                            <!-- No documents -->
                            <div class="p-4 border border-dashed border-gray-300 rounded-md bg-gray-50 text-center text-sm text-gray-500">
                                No project documents available yet.
                            </div>
                        @endif
                    </div>


                    <div class="grid grid-cols-12 gap-x-2  " id="add_project_document">

                        
                        <div class="space-y-2 col-span-12     ">

                            <div class="space-y-2 col-span-12 sm:col-span-4  ">
                                <label for="type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                                    Add New Document Type
                                </label>
                                <select
                                    class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  "
                                    wire:model.live="document_type_id"
                                    
                                    >
                                    <option value="">Select Document Type</option>
                                    @foreach($documentTypes as $type)
                                        <option value="{{ $type->id }}">{{ $type->name }}</option>
                                    @endforeach 

                                </select>


                                @error('document_type_id')
                                    <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                                @enderror 
                                
                            </div>


                            <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                                Document Attachments
                            </label>

                            <livewire:dropzone
                                wire:model="attachments"
                                :rules="['file', 'mimes:png,jpeg,jpg,pdf,docx,xlsx,csv,txt,zip', 'max:20480']"
                                :multiple="true" />


                            @error('attachments')
                                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                            @enderror 

                        </div>

    
                        


                    </div>
                    <!-- End Grid -->




                    @if(Auth::user()->hasRole('User')) 
                    <!-- End Grid -->
                    <p class="text-sm text-gray-600 mt-2">{{ !empty($reviewer_due_date) ? 'Expect to get a review at '.\Carbon\Carbon::parse($reviewer_due_date)->format('d M, h:i A') : '' }}</p>
                    @endif

                    <div class="mt-5 flex justify-center gap-x-2">
                        <a href="{{ route('project.show',['project' => $project->id]) }}" class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:bg-red-700 disabled:opacity-50 disabled:pointer-events-none">
                            Cancel
                        </a>
                        <button type="submit" class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                        Save
                        </button>
                        
                        @if( Auth::user()->can('system access global admin') || Auth::user()->can('project submit') )
                        <button {{ $project->allow_project_submission ? '' : 'disabled' }} type="button"
                            onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
                            wire:click.prevent="submit_project({{ $project_id }})"
                            
                            class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                            Submit
                        </button> 
                        @endif


                    </div>

                </div>

            </div>
        </div>
        <!-- End Card -->
    </form>

   

    <!--  Loaders -->
         

        {{-- wire:target="save"   --}}
        <div wire:loading  wire:target="save"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Saving record...
                    </div>
                </div>
            </div>

            
        </div>


        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>

    <!--  ./ Loaders -->

         

</div>
<!-- End Card Section -->

<!-- Card Section -->
<div class=" p-4 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
    <!-- Card -->
    <div class="bg-white border rounded-xl shadow col-span-12"> 
        
         
        <div class="  p-4">

            {{-- <h2 class="text-lg font-semibold text-gray-800 ">
                Project Logs
            </h2> 
            --}}

            <!-- Header -->
            <div class=" min-w-full px-3 py-2 grid gap-3 lg:flex lg:justify-between lg:items-center  ">
                <div>
                    <input type="text" wire:model.live="search"
                    class="text-nowrap min-w-32 py-2 px-3 inline-flex items-center gap-x-2 border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  "
                    placeholder="Search">
                </div>

                <div>
                    <div class=" grid grid-cols-3 lg:inline-flex  gap-x-2">

 
                        

                        <div class="text-nowrap inline-flex items-center gap-x-2">

                            <select wire:model.live="log_filter" class="min-w-36 py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                                <option value="">Logs filter</option> 
                                <option >Project Logs</option>
                                <option >Discussion Logs</option>
                                <option >Project Reviewer Logs</option>
                                <option >Project Document Logs</option>
                                <option >Project Attachment Logs</option> 

                            </select>
                        </div>
                        @if($log_filter == "Project Reviewer Logs")
                        <div class="text-nowrap inline-flex items-center gap-x-2">

                            <select wire:model.live="review_status" class="min-w-36 py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                                <option value="">Review Status</option> 
                                
                                {{-- @foreach ($review_status_options as $key => $value )
                                    <option value="{{ $key }}">{{ $value }}</option>
                                @endforeach --}}
                                <option value=" ">Select review status</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                                <option value="pending">Pending</option>

                            </select>
                        </div>
                        @endif


                        @if($log_filter == "Project Document Logs")
                            <div class="text-nowrap inline-flex items-center gap-x-2">

                                <select wire:model.live="project_document_id" class="min-w-32 py-2 px-3 pe-9 max-w-32 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                                    <option value="">Filter Document</option>
                                    @if(!empty($project_documents))
                                        @foreach ($project_documents as $project_document )
                                            <option value="{{ $project_document->id }}">{{ $project_document->document_type->name }}</option> 
                                        @endforeach 
                                    @endif
                                </select>
                            </div>
                        @endif

                        <div class="text-nowrapinline-flex items-center gap-x-2">

                            <select wire:model.live="sort_by" class="min-w-32 py-2 px-3 pe-9 max-w-32 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                                <option value="">Sort By</option>
                                <option>Name A - Z</option>
                                <option>Name Z - A</option>
                                <option>Federal Agency A - Z</option>
                                <option>Federal Agency Z - A</option>
                                <option>Description A - Z</option>
                                <option>Description Z - A</option>
                                <option>Nearest Submission Due Date</option>
                                <option>Farthest Submission Due Date</option>
                                <option>Nearest Reviewer Due Date</option>
                                <option>Farthest Reviewer Due Date</option>
                                <option>Latest Added</option>
                                <option>Oldest Added</option>
                                <option>Latest Updated</option>
                                <option>Oldest Updated</option>
                            </select>
                        </div>

                        {{-- @if( Auth::user()->can('activity log delete') || Auth::user()->can('system access global admin'))  --}}
                        @if(  Auth::user()->can('system access global admin') || 
                        // Auth::user()->can('project delete')
                        Auth::user()->can('system access user')
                        
                        )
                            <button
                                onclick="confirm('Are you sure, you want to delete this records?') || event.stopImmediatePropagation()"
                                wire:click.prevent="deleteSelected"
                                {{ $count == 0 ? 'disabled' : '' }}
                                class=" text-nowrap py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-red-500 text-white shadow-sm hover:bg-red-50 hover:text-red-600 hover:border-red-500 focus:outline-red-500 focus:text-red-500 focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none " >
                                <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                                Delete ({{ $count }})
                            </button>
                        @endif

                        

                        <button 
                            wire:click="getActivityLogsProperty"
                            type="button"
                            class="text-nowrap py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-sky-500 text-white shadow-sm hover:bg-sky-50 hover:text-sky-600   hover:border-sky-500 focus:outline-sky-500 focus:text-sky-500 focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none " >
                            {{-- <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path fill="#ffffff" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm144 276c0 6.6-5.4 12-12 12h-92v92c0 6.6-5.4 12-12 12h-56c-6.6 0-12-5.4-12-12v-92h-92c-6.6 0-12-5.4-12-12v-56c0-6.6 5.4-12 12-12h92v-92c0-6.6 5.4-12 12-12h56c6.6 0 12 5.4 12 12v92h92c6.6 0 12 5.4 12 12v56z"/></svg> --}}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path fill="#ffffff" d="M370.7 133.3C339.5 104 298.9 88 255.8 88c-77.5 .1-144.3 53.2-162.8 126.9-1.3 5.4-6.1 9.2-11.7 9.2H24.1c-7.5 0-13.2-6.8-11.8-14.2C33.9 94.9 134.8 8 256 8c66.4 0 126.8 26.1 171.3 68.7L463 41C478.1 25.9 504 36.6 504 57.9V192c0 13.3-10.7 24-24 24H345.9c-21.4 0-32.1-25.9-17-41l41.8-41.7zM32 296h134.1c21.4 0 32.1 25.9 17 41l-41.8 41.8c31.3 29.3 71.8 45.3 114.9 45.3 77.4-.1 144.3-53.1 162.8-126.8 1.3-5.4 6.1-9.2 11.7-9.2h57.3c7.5 0 13.2 6.8 11.8 14.2C478.1 417.1 377.2 504 256 504c-66.4 0-126.8-26.1-171.3-68.7L49 471C33.9 486.1 8 475.4 8 454.1V320c0-13.3 10.7-24 24-24z"/></svg>
                        </button>


                    </div>
                </div>

                


            </div>
            <!-- End Header -->


            <!-- Timeline -->
            <div>
                
                @if(!empty($activity_logs) && count($activity_logs) > 0)
                    @foreach ($activity_logs as $activity_log)
                        <!-- Log Item -->
                        <div class="flex gap-x-3 relative group rounded-lg hover:bg-gray-100  ">
                            <a class="z-1 absolute inset-0" href="#"></a>
                        
                            <!-- Icon -->
                            <div class="relative last:after:hidden after:absolute after:top-0 after:bottom-0 after:start-3.5 after:w-px after:-translate-x-[0.5px] after:bg-gray-200  ">
                                <div class="relative z-10 size-7 flex justify-center items-center">
                                <div class="size-2 rounded-full bg-white border-2 border-gray-300 group-hover:border-gray-600 "></div>
                                </div>
                            </div>
                            <!-- End Icon -->
                        
                            <!-- Right Content -->
                            <div class="grow p-2 pb-8">
                                <h3 class="flex gap-x-1.5 font-semibold text-gray-800 ">
                                
                                    {{ $activity_log->log_action }}
                                </h3> 
                                <p class="mt-1 text-sm text-gray-600 ">
                                     ( {{ $activity_log->created_at->diffForHumans() }} )  
                                     {{-- <br> {{ $activity_log->created_at->format('j M, Y g:i A') }}  --}}

                                </p>
                                <button type="button" class="mt-1 -ms-1 p-1 relative z-10 inline-flex items-center gap-x-2 text-xs rounded-lg border border-transparent text-gray-500 hover:bg-white hover:shadow-2xs disabled:opacity-50 disabled:pointer-events-none  ">
                                    <img class="shrink-0 size-4 rounded-full" src="https://www.shutterstock.com/image-vector/vector-flat-illustration-grayscale-avatar-600nw-2281862025.jpg" alt="Avatar">
                                    {{ $activity_log->log_username }}
                                </button>
                            </div>
                            <!-- End Right Content -->
                        </div>
                        <!-- End Log Item -->
                    @endforeach
                        
                @else   
                    <!-- Item -->
                    <div class="flex gap-x-3 relative group rounded-lg hover:bg-gray-100  ">
                         
                         
                    
                        <!-- Right Content -->
                        <div class="grow p-2  ">
                            <h3 class="flex   font-semibold text-gray-800 ">
                            
                                No Logs found
                            </h3>
                             
                        </div>
                        <!-- End Right Content -->
                    </div>
                    <!-- End Item -->
                @endif
            </div>
            <!-- End Timeline -->

            <!-- Footer -->
            <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-t border-gray-200 ">
                {{ $activity_logs->links() }}

                <div class="inline-flex items-center gap-x-2">
                    <p class="text-sm text-gray-600 ">
                    Showing:
                    </p>
                    <div class="max-w-sm space-y-3">
                    <select wire:model.live="record_count" class="py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                        <option>200</option>
                    </select>
                    </div>
                    <p class="text-sm text-gray-600 ">
                        {{ count($activity_logs) > 0 ? 'of '.$activity_logs->total()  : '' }}
                    </p>
                </div>


            </div>
            <!-- End Footer -->


        </div>
    </div>


    <!-- Floating Loading Notification -->
    <div 
        wire:loading 
    class="fixed top-4 right-4 z-50 w-[22rem] max-w-[calc(100vw-2rem)]
            rounded-2xl border border-slate-200 bg-white shadow-lg"
    role="status"
    aria-live="polite"
    >
        <div class="flex items-start gap-3 p-4">
            <!-- Spinner -->
            <svg class="h-5 w-5 mt-0.5 animate-spin text-slate-600 shrink-0"
                viewBox="0 0 24 24" fill="none">
            <circle class="opacity-25" cx="12" cy="12" r="10"
                    stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 0 1 8-8v3a5 5 0 0 0-5 5H4z" />
            </svg>

            <!-- Text + Progress -->
            <div class="flex-1 min-w-0">
                <div class="text-sm font-semibold text-slate-900">
                    Loading data…
                </div>
                <div class="mt-0.5 text-xs text-slate-600">
                    Fetching the latest records. Please wait.
                </div>

                <!-- Indeterminate Progress Bar -->
                <div class="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                    class="absolute inset-y-0 left-0 w-1/3 rounded-full bg-slate-400"
                    style="animation: indeterminate-bar 1.2s ease-in-out infinite;"
                    ></div> 

                </div>
            </div>
        </div>
    </div>

         


    <!-- ./  Loaders -->



    @push('scripts')
        <script>

            (function () {

                function getData(){
                    window.pageProjectId = @json(optional(request()->route('project'))->id ?? request()->route('project') ?? null);
                    console.log(window.pageProjectId);

                    const pageProjectId = window.pageProjectId; // can be null
                    // 2) Conditionally listen to the model-scoped user channel
                    if (pageProjectId) {
                        console.log(`listening to : ${pageProjectId}`);
                        window.Echo.private(`project.${pageProjectId}`)
                            .listen('.event', (e) => {
                                console.log('[project model-scoped]');

                                let dispatchEvent = `projectEvent.${pageProjectId}`;
                                Livewire.dispatch(dispatchEvent); 

                                console.log(dispatchEvent); 

                            });
                    }
                }

                /**
                 * 1. Full page load (hard refresh, direct URL, normal navigation)
                 */
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', () => {
                        getData();
                    });
                } else {
                    // DOM already loaded
                    getData();
                }

                /**
                 * 2. Livewire SPA navigation (wire:navigate)
                 */
                document.addEventListener('livewire:navigated', () => {
                    getData();
                });

            })();
 


        </script>
    @endpush

</div>
<!-- End Timeline -->
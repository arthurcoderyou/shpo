<!-- Card Section -->
<div   class="  p-4 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
     
    
    <form class=" col-span-12  " wire:submit="save">
        <!-- Card -->
        <div class="bg-white rounded-2xl border border-slate-200 ">


            <div class="  p-4 space-y-2">
                 

                <!-- Grid -->
                <div class="grid grid-cols-12 gap-x-2  ">

                    <div class="space-y-2 col-span-12 sm:col-span-4 ">
                        <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Name
                        </label>

                        <input
                        autofocus autocomplete="name"
                        wire:model="name"
                        id="name" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('name')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-4 ">
                        <label for="federal_agency" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Federal Agency
                        </label>

                        <input
                        autofocus autocomplete="federal_agency"
                        wire:model="federal_agency"
                        id="federal_agency" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('federal_agency')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Type
                        </label>


                        <select
                        autocomplete="type"
                        wire:model="type"
                        id="type"
                        class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  ">
                            <option selected="">Select type</option>

                            @if(!empty($project_types))
                                @foreach ($project_types as $type_id => $type_name )
                                    <option>{{ $type_name }}</option> 
                                @endforeach 
                            @endif
                        </select>

                        {{-- <input
                        autofocus autocomplete="type"
                        wire:model="type"
                        id="type" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""> --}}

                        @error('type')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    {{-- <div class="space-y-2 col-span-12   ">
                        <label for="location" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Location 
                        </label>

                        <input
                        autofocus autocomplete="location"
                        wire:model="location"
                        id="location" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('location')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror

                        
                    </div> --}}
                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="street" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Street Location
                        </label>

                        <input
                        autofocus autocomplete="street"
                        wire:model="street"
                        id="street" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('street')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="area" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Area
                        </label>

                        <input
                        autofocus autocomplete="area"
                        wire:model="area"
                        id="area" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('area')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="lot_number" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Lot #
                        </label>

                        <input
                        autofocus autocomplete="lot_number"
                        wire:model="lot_number"
                        id="lot_number" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('lot_number')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>



                    <div class="space-y-2 col-span-12   ">
                        <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Description
                        </label>

                        <textarea
                        autofocus autocomplete="description"
                        wire:model="description"
                        id="description"  class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""></textarea>

                        @error('description')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>


                </div>

                
                <div class="p-4 space-y-4 rounded-2xl border border-slate-200">

                    <!-- Header -->
                    <div>
                        <h2 class="text-lg font-semibold text-gray-800">
                            Project Subscribers
                        </h2>
                        <p class="text-sm text-gray-500">
                            Users that will be notified on project updates.
                        </p>
                    </div>

                    <!-- Search -->
                    <div>
                        <label for="subscriber-search" class="block text-sm font-medium text-gray-700">
                            Search for User Name
                        </label>
                        <div class="relative mt-1">
                            <input id="subscriber-search"
                                type="text"
                                wire:model.live="query"
                                placeholder="Type to search..."
                                class="block w-full rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm px-3 py-2"
                            >
                        </div>
                    </div>

                    <!-- Search Results -->
                    @if(!empty($users))
                        <ul class="border rounded-md mt-2 bg-white shadow-sm max-h-48 overflow-auto divide-y divide-gray-100">
                            @foreach($users as $user)
                                <li wire:click="addSubscriber({{ $user->id }})"
                                    class="px-4 py-2 cursor-pointer hover:bg-sky-50 transition text-sm">
                                    {{ $user->name }}
                                </li>
                            @endforeach
                        </ul>
                    @endif

                    <!-- Selected Subscribers -->
                    <div>
                        <h3 class="text-sm font-semibold text-gray-700 mb-1">
                            Selected Subscribers
                        </h3>

                        @if(!empty($selectedUsers))
                            <ul class="space-y-1">
                                @foreach($selectedUsers as $index => $user)
                                    <li class="flex items-center justify-between bg-sky-50 px-3 py-2 rounded-md text-sm text-sky-800 border border-sky-100">
                                        <span class="truncate">{{ $user['name'] }}</span>
                                        <button wire:click="removeSubscriber({{ $index }})"
                                                class="ml-2 text-red-500 hover:text-red-600 focus:outline-none"
                                                title="Remove">
                                            ✕
                                        </button>
                                    </li>
                                @endforeach
                            </ul>
                        @else
                            <p class="text-sm text-gray-400">No subscribers selected.</p>
                        @endif
                    </div>
    

                </div>  




                <div class="mt-5 flex justify-center gap-x-2">
                    <a href="{{ $home_route }}"
                    wire:navigate
                    class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:bg-red-700 disabled:opacity-50 disabled:pointer-events-none">
                        Cancel
                    </a>
                    <button type="submit" class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                    Save
                    </button>
                    
                    {{-- @if( Auth::user()->can('system access global admin') || Auth::user()->can('project submit') )
                    <button {{ $project->allow_project_submission ? '' : 'disabled' }} type="button"
                        onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
                        wire:click.prevent="submit_project({{ $project_id }})"
                        
                        class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                        Submit
                    </button> 
                    @endif --}}


                </div>

                 

            </div>
        </div>
        <!-- End Card -->
    </form>

    
 



    <!--  Loaders -->
         

        {{-- wire:target="save"   --}}
        <div wire:loading  wire:target="save"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Saving record...
                    </div>
                </div>
            </div>

            
        </div>


        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>


        {{-- wire:target="location"   --}}
        <div wire:loading  wire:target="location"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Loading Location...
                    </div>
                </div>
            </div>

            
        </div>

    <!--  ./ Loaders -->

         

</div>
<!-- End Card Section -->

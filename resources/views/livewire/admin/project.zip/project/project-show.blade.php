<!-- Card Section -->
<div id="project-wrapper" data-project-id="{{ $project->id }}" class="max-w-[85rem] px-4 py-6 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
    {{-- The whole world belongs to you. --}}
    {{-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places"
     async
    defer></script> --}}
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places&callback=initMap"
        async
        defer>
    </script>
    
    {{-- <div wire:loading class="loading-overlay">
        <div style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
            <div></div>
            <div></div>
        </div>
    </div> --}}

    <div class=" col-span-12  "   >
         
        <!-- Project Details Section -->
        <div class="bg-white rounded-2xl shadow p-6 mb-6 space-y-6">
            
                
            <div class="flex justify-between items-start flex-wrap gap-6">
                <!-- Left: Main Info -->
                <div class="flex-1 min-w-[300px] space-y-2">
                    <h1 class="text-2xl font-semibold text-sky-800">
                        {{-- <span class="text-gray-500">Document:</span>  --}}

                        @if(request()->routeIs('project.review'))
                            <span class="text-gray-500">Project Review:</span> {{ $project->name }}
                        @else
                            <span class="text-gray-500">Project:</span> {{ $project->name }}
                        @endif

                        
                    </h1>
                    <div class="flex gap-x-2">

                        <!-- Edit -->
                        <a href="{{ route('project.edit',['project' => $project->id]) }}" 
                            wire:navigate
                            class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border  bg-blue-500 text-white hover:bg-blue-700 focus:outline-hidden focus:border-blue-400  disabled:opacity-50 disabled:pointer-events-none">
                            Edit
                        </a>
                        <!-- Edit -->

                        @if($project->status !== "draft")
                            <!-- Discussion Logs -->
                            <a href="#discussion" 
                                data-hs-scrollspy="#discussion" 
                                data-hs-scrollspy-offset="100"
                                class="hs-scrollspy py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-500 text-gray-500 hover:border-gray-400 hover:text-gray-400 focus:outline-hidden focus:border-gray-400 focus:text-gray-400 disabled:opacity-50 disabled:pointer-events-none">
                                Discussion
                            </a>
                            <!-- Discussion Logs -->
                        @endif


                        <!-- Activity Logs -->
                        <a href="#project_logs" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-teal-500 text-teal-500 hover:border-teal-400 hover:text-teal-400 focus:outline-hidden focus:border-teal-400 focus:text-teal-400 disabled:opacity-50 disabled:pointer-events-none">
                            Logs
                        </a>
                        <!-- Activity Logs -->


                    </div>
                    

                    {{-- <livewire:layout.activity-log-panel /> --}}

                    
                    @if(
                        // Auth::user()->hasRole('Reviewer') && !request()->routeIs('project.review') && 
                        \App\Helpers\ProjectHelper::checkIfUserIsProjectReviewer($project->id ) && $project->status !== "approved" 
                    )
                        @if( $project->getCurrentReviewer()->user_id == auth()->user()->id)
                            @if(request()->routeIs('project.review'))
                                <a href="#review_create"
                                    
                                    class="inline-block text-sm text-white bg-sky-600 hover:bg-sky-700 font-medium px-3 py-1 rounded transition">
                                    Click to Review
                                </a>
                            @else 
                                 <a href="{{ route('project.review',['project' => $project->id ]) }}"
                                    wire:navigate
                                class="inline-block text-sm text-white bg-sky-600 hover:bg-sky-700 font-medium px-3 py-1 rounded transition">
                                    Click to Review
                                </a>
                            @endif
                        @else
                            <p class="inline-block text-sm text-sky-700  font-medium px-3 py-1 rounded transition">Your not the current reviewer for the project</p>

                        @endif
                    @endif

                        
                    <p class="text-sm text-gray-600">{{ $project->federal_agency }}</p>
                    <p class="text-sm text-blue-600 font-medium">{{ $project->type }}</p>

                    @if(!Auth::user()->hasRole('User'))
                        <div class="space-y-1">
                            <p class="text-sm text-green-600 font-medium">
                                Project #: {{ $project->project_number ?? 'NOT SET' }}
                            </p>
                            <p class="text-sm text-yellow-600 font-medium">
                                SHPO #: {{ $project->shpo_number ?? 'NOT SET' }}
                            </p>
                            @if(!empty($project->project_references) && count($project->project_references) > 0)
                            <p class="text-sm text-gray-600 font-medium">
                                References: 
                                
                                
                                <div class="flex gap-x-2">
                                    @foreach ($project->project_references as $project_reference )
                                        <!-- View project reference -->
                                        <a href="{{ route('project.show',['project' => $project_reference->referenced_project->id]) }}"
                                            wire:navigate
                                            class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border  bg-blue-500 text-white hover:bg-blue-700 focus:outline-hidden focus:border-blue-400  disabled:opacity-50 disabled:pointer-events-none">
                                            {{ $project_reference->referenced_project->shpo_number ? $project_reference->referenced_project->shpo_number : "" }}
                                        </a>
                                        <!-- View project reference -->
                                    @endforeach
                                    
 

                                </div>
                    
                                

                            </p>
                            @endif

                        </div>
                    @endif
                </div>

                <!-- Right: Status Info -->
                <div class="min-w-[280px] space-y-3">
                    <div class="text-sm text-gray-700">
                        <p><strong>Project Status:</strong> {!! $project->getStatus() !!}</p>

                        @if($project->status !== "approved" && $project->status !== "draft" && !empty($project->getCurrentReviewer()))
                            <p><strong>Review Status:</strong> {!! $project->getCurrentReviewer()->getReviewStatus() !!}</p>
                            <p><strong>Currently Reviewed by:</strong><br>{{ $project->getCurrentReviewer()->user->name ?? "Open Review" }}</p>


                            @switch($project->getCurrentReviewer()->reviewer_type)
                                @case("document")
                                    <p><strong>Document:</strong> {!! $project->getCurrentReviewer()->project_document->document_type->name ?? "" !!}</p>
                                    @break
                                @case("initial")
                                    <p><strong>Initial Review</strong> </p>
                                    @break
                                @case("final")
                                    <p><strong>Final Review</strong> </p>
                                    @break
                                @default    
                                    <p><strong>Review</strong> </p>
                            @endswitch 
 
                            
                        @endif
                    </div>

                    @if($project->status !== "approved" && $project->status !== "draft")
                        <div class="text-sm text-gray-700">
                            <hr class="my-2">

                            <p class="font-medium">Update Schedule:
                                @if (\Carbon\Carbon::parse($project->submitter_due_date)->isPast())
                                    <span class="text-red-500 font-semibold">Overdue</span>
                                @else
                                    <span class="text-lime-600 font-semibold">On Time</span>
                                @endif
                            </p>
                            <p>
                                Expected update submission:<br>
                                <strong class="text-gray-800">{{ \Carbon\Carbon::parse($project->submitter_due_date)->format('M d, Y h:i A') }}</strong>
                            </p>
                        </div>

                        @if(!Auth::user()->hasRole('User'))
                            <div class="text-sm text-gray-700">
                                <hr class="my-2">

                                <p class="font-medium">Review Schedule:
                                    @if (\Carbon\Carbon::parse($project->reviewer_due_date)->isPast())
                                        <span class="text-red-500 font-semibold">Overdue</span>
                                    @else
                                        <span class="text-lime-600 font-semibold">On Time</span>
                                    @endif
                                </p>
                                <p>
                                    Expected review by:<br>
                                    <strong class="text-gray-800">{{ \Carbon\Carbon::parse($project->reviewer_due_date)->format('M d, Y h:i A') }}</strong>
                                </p>
                            </div>
                        @endif
                    @endif
                </div>
            </div>

            <!-- Project Description -->
            <div>
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Project Description</h3>
                <div class="text-sm text-gray-700 bg-gray-50 p-4 rounded border border-gray-200 mb-2">
                    {{ $project->description }}
                </div>
                

                <!-- Project Documents List -->
                <div class="space-y-2">
                    <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                        Project Documents   
                    </label>

                    @if(!empty($project->project_documents) && $project->project_documents->count())
                        <ul class="divide-y divide-gray-200 border border-gray-200 rounded-lg overflow-hidden bg-white">
                            @foreach ($project->project_documents as $project_document)
                                <li class="px-4 py-4 sm:px-6 hover:bg-gray-50 transition flex items-start justify-between">
                                    <div>
                                        <p class="text-base font-semibold text-gray-800">
                                            {{ $project_document->document_type->name }}
                                        </p>
                                        <p class="text-sm text-gray-600">
                                            {{ $project_document->project_attachments->count() }} attachment{{ $project_document->project_attachments->count() !== 1 ? 's' : '' }} found
                                        </p>
                                        <p class="text-xs text-gray-500 mt-1">
                                            Last updated {{ $project_document->updated_at->diffForHumans() }}
                                        </p>

                                        <p class="text-xs text-gray-500 mt-1">
                                             {{ $project_document->last_submitted_at ? "Last submitted ".$project_document->last_submitted_at->diffForHumans() : "Not Submitted Yet" }}
                                        </p>

                                    </div>

                                    <div class="flex flex-col items-end gap-1 text-sm whitespace-nowrap">
 
                                        @if(
                                            Auth::user()->can('system access global admin') || Auth::user()->can('system access admin') || 
                                            (Auth::user()->can('system access user') && $project->created_by == Auth::id() && Auth::user()->can('project document edit') )
                                        )

                                            @if($project->allow_project_submission == true)
                                                <a target="_blank" href="{{ route('project.project_document', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                    wire:navigate
                                                class="text-blue-600 hover:underline hover:text-blue-800 flex items-center gap-x-1">
                                                    Update
                                                    <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path d="m9 18 6-6-6-6" />
                                                    </svg>
                                                </a>
                                            @else
                                                <a target="_blank" href="{{ route('project.project_document', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                    wire:navigate
                                                class="text-gray-600 hover:underline hover:text-gray-800 flex items-center gap-x-1">
                                                    View
                                                    <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path d="m9 18 6-6-6-6" />
                                                    </svg>
                                                </a>
 

                                            @endif

                                            {{-- <button type="button"
                                                onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()"
                                                wire:click.prevent="delete({{ $project_document->id }})"
                                                class="text-red-600 hover:underline hover:text-red-800 flex items-center gap-x-1">
                                                Delete
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </button> --}}

                                        @else 

                                            <a target="_blank" href="{{ route('project.project_document', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                wire:navigate
                                            class="text-gray-600 hover:underline hover:text-gray-800 flex items-center gap-x-1">
                                                View
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </a>
 

                                        @endif 


                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <!-- No documents -->
                        <div class="p-4 border border-dashed border-gray-300 rounded-md bg-gray-50 text-center text-sm text-gray-500">
                            No project documents available yet.
                        </div>
                    @endif


                    @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create'))
                        <div  >
                            <!-- Add new project document -->
                            <a href="{{ route('project.project_document.create',['project' => $project->id]) }}"
                                 {{-- wire:navigate  --}}
                                 target="_blank" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border  bg-blue-500 text-white hover:bg-blue-700 focus:outline-hidden focus:border-blue-400  disabled:opacity-50 disabled:pointer-events-none">
                                Add new project document
                            </a>
                            <!-- Add new project document -->

                        </div>
                    @endif


                </div>


            </div>

            <!-- Map -->
            <div class="grid grid-cols-12 gap-x-2  ">

                <div class="space-y-2 col-span-12 my-1  ">

                    <!-- Map -->
                    <div class="flex-row md:flex items-center justify-between my-1 ">
                        
                    
                            
                        <div>
                            <p class="text-sm text-gray-600 ">
                                <strong>Location:</strong> {!! $location !!}
                            </p> 

                        </div>
                        <div>
                            <p class="text-sm text-gray-600 ">
                                <strong>Latitude:</strong> {!! $latitude !!}
                            </p> 

                        </div>

                        <div>
                            <p class="text-sm text-gray-600 ">
                                <strong>Longitude:</strong> {!! $longitude !!}
                            </p> 

                        </div>



                    </div>
                    <!-- End Map -->


                </div>


                <div class="space-y-2 col-span-12    ">
                    <div>
                        
                        <div id="map" style="height: 500px; width: 100%;" wire:ignore></div>
                    {{-- <button wire:click="saveLocation">Save Location</button> --}}
                    </div>


                        
                </div>

            </div>
            <!-- ./ Map -->

            
            <!-- About -->
            <div class="mt-4">
            

                <ul class="mt-5 flex flex-col gap-y-3">
                        
                    
                    <li class="flex items-center gap-x-2.5">
                        <svg class="shrink-0 size-3.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M304 128a80 80 0 1 0 -160 0 80 80 0 1 0 160 0zM96 128a128 128 0 1 1 256 0A128 128 0 1 1 96 128zM49.3 464l349.5 0c-8.9-63.3-63.3-112-129-112l-91.4 0c-65.7 0-120.1 48.7-129 112zM0 482.3C0 383.8 79.8 304 178.3 304l91.4 0C368.2 304 448 383.8 448 482.3c0 16.4-13.3 29.7-29.7 29.7L29.7 512C13.3 512 0 498.7 0 482.3z"/></svg>
                        <p class="text-[13px] text-gray-500   hover:text-gray-800 hover:decoration-2 focus:outline-none focus:decoration-2 " href="#">
                            Submitted by {{ $user->name }}
                        </p>
                    </li>

                    <li class="flex items-center gap-x-2.5">
                        <svg class="shrink-0 size-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                        <a class="text-[13px] text-gray-500 underline hover:text-gray-800 hover:decoration-2 focus:outline-none focus:decoration-2 " 
                        href="mailto:{{ $user->email }}">
                            {{ $user->email }}
                        </a>
                    </li>
                
                    
                </ul> 


                @if ($errors->any())
                         
                    @foreach ($errors->all() as $error) 


                        <div class="mt-2 bg-red-100 border border-red-200 text-sm text-red-800 rounded-lg p-4 " role="alert" tabindex="-1" aria-labelledby="hs-soft-color-danger-label">
                            <span id="hs-soft-color-danger-label" class="font-bold">Error: </span>
                            {{ $error }}
                        </div>


                    @endforeach 
                @endif 


                @if (session()->has('error'))
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 mt-5" role="alert">
                        {{ session('error') }}
                    </div>
                @endif

                <div class="text-end">

 
                    
                    @if($project->status !== "approved")

                        @if(
                            Auth::user()->can('system access global admin') || Auth::user()->can('system access admin')  || 
                            (Auth::user()->can('system access user') && $project->created_by == Auth::id() ) || 
                            (Auth::user()->can('system access reviewer') && $project->created_by == Auth::id() )
                        )

                            <a href="{{ $home_route }}"
                            wire:navigate
                            class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:bg-red-700 disabled:opacity-50 disabled:pointer-events-none">
                                Cancel
                            </a>

                            
                            <button {{ $project->allow_project_submission ? '' : 'disabled' }} type="button"
                                wire:click="submit_project({{ $project_id }})"
                                class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                                Submit
                            </button> 

                            @if($project->allow_project_submission == true)
                                <a href="{{ route('project.edit',['project' => $project]) }}" 
                                    wire:navigate
                                    class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                                    Edit
                                </a> 
                            @endif


                        @endif 

                    @else
                        <p class="text-sm text-lime-600  ">
                        Project is approved
                        </p>
                    @endif
                    
                </div>
                
                

            </div>
            <!-- End About -->


        </div>

                

 
    </div>


    <aside class="col-span-12  mt-2 ">
        <div class="bg-white rounded-xl shadow  ">
            <div class="  p-4">

                <div class="sm:col-span-12">
                    <h2 class="text-lg font-semibold text-gray-800 ">
                        Project Subscribers  
                    </h2>
                    <p class="text-gray-500 text-xs">Users that will be notified on project updates</p>
                </div> 

                {{-- <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                    Search for User Name
                </label>

                <input type="text" wire:model.live="query" placeholder="Type to search..." class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  "> --}}
                
                <!-- Search Results Dropdown -->
                @if(!empty($users))
                    <ul class="border rounded mt-2 bg-white w-full max-h-48 overflow-auto">
                        @foreach($users as $user)
                            <li wire:click="addSubscriber({{ $user->id }})" class="p-2 cursor-pointer hover:bg-gray-200">
                                {{ $user->name }}
                            </li>
                        @endforeach
                    </ul>
                @endif
            
                <!-- Selected Subscribers -->
                <div class="mt-4">
                    <h3 class="font-bold">Selected Subscribers:</h3>
                    
                    @if(!empty($selectedUsers))
                        <ul>
                            @foreach($selectedUsers as $index => $user)
                                <li class="flex items-center justify-between bg-gray-100 p-2 rounded mt-1 text-truncate">
                                    <span>{{ $user['name'] }}</span>
                                    {{-- <button wire:click="removeSubscriber({{ $index }})" class="text-red-500">❌</button> --}}
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <p class="text-gray-500">No subscribers selected.</p>
                    @endif
                </div>

            </div>

        </div>
    </aside>



    <script>
        let map, marker, searchBox;

        const location_directions = @json($location_directions);
        const latitude = parseFloat(location_directions[0][0].latitude) ? parseFloat(location_directions[0][0].latitude) : 13.4443;
        const longitude = parseFloat(location_directions[0][0].longitude) ? parseFloat(location_directions[0][0].longitude) : 144.7937;

        console.log("Latitude:", latitude, "Longitude:", longitude);

        console.log(latitude);
        function initMap() {
 

            map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: latitude, lng: longitude }, // Centered on Guam
                zoom: 11,
                // mapTypeId: google.maps.MapTypeId.SATELLITE // ✅ Default to Satellite view
            });

            marker = new google.maps.Marker({
                position: map.getCenter(),
                map: map,
                // draggable: true
            });

            // const input = document.getElementById("search-box");
            // searchBox = new google.maps.places.SearchBox(input);
            // // map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

            // searchBox.addListener("places_changed", function () {
            //     let places = searchBox.getPlaces();
            //     if (places.length == 0) return;

            //     let place = places[0];
            //     map.setCenter(place.geometry.location);
            //     marker.setPosition(place.geometry.location);


            //     @this.set('latitude', place.geometry.location.lat());
            //     @this.set('longitude', place.geometry.location.lng());
            //     @this.set('location', place.name);

                 

            // });

            // const geocoder = new google.maps.Geocoder();

            // marker.addListener("dragend", function () {
            //     let lat = marker.getPosition().lat();
            //     let lng = marker.getPosition().lng();

            //     // Reverse geocode to get location name
            //     geocoder.geocode({ location: { lat, lng } }, function (results, status) {
            //         if (status === "OK" && results[0]) {
            //             let locationName = results[0].formatted_address;

            //             // Send data to Livewire
            //             @this.set('latitude', lat);
            //             @this.set('longitude', lng);
            //             @this.set('location', locationName);

            //             console.log("Updated Location:", locationName);
            //         } else {
            //             console.error("Geocoder failed: " + status);
            //         }
            //     });
            // });


             
        }

        window.onload = initMap;

         
    </script>


    <!--  Loaders -->
        {{-- wire:target="table"   --}}
        <div wire:loading 
            class="p-0 m-0"
            style="padding: 0; margin: 0;">
            <div class="absolute right-4 top-4 z-10 inline-flex items-center gap-2 px-4 py-3 rounded-md text-sm text-white bg-blue-600 border border-blue-700 shadow-md animate-pulse mb-4 mx-3">
                <div>   
                    <svg class="h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                    </svg>
                </div>
                <div>
                    Loading new data, please wait...
                </div> 
            </div>
        </div>

        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>
 


    <!-- ./  Loaders -->



</div>
<!-- End Card Section -->

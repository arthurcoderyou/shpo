<!-- Card Section -->
<div id="project-wrapper"  class="  p-4 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
    <div class="col-span-12 ">
        <!-- Meta Grid -->
        <section class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <!-- Left: Core fields -->
            <div class="md:col-span-2 space-y-4">
                <!-- Company & Location -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
                    <h2 class="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Details</h2>
                    <dl class="grid grid-cols-1 gap-3 sm:grid-cols-2">

                        
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Project Status </dt>
                            <dd class="text-sm text-slate-900">
                                
                                 @php 
                                    $config = $this->returnStatusConfig($project->status); 
                                @endphp
                                <span class="rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset {{ $config['bg'].' '.$config['text'].' '.$config['ring'] }}">
                                    {{ $config['label'] }}
                                </span>
                            </dd>
                        </div>

                        <div>
                            <dt class="text-xs font-medium text-slate-500">Lot #</dt>
                            <dd class="text-sm text-slate-900">{{ $project->lot_number ?? 'L-001' }}</dd>
                        </div>

                        <div>
                            <dt class="text-xs font-medium text-slate-500">Location</dt>
                            <dd class="text-sm text-slate-900">{{ $project->location ?? 'DSI' }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Type</dt>
                            <dd class="text-sm text-slate-900">{{ ucfirst($project->type ?? 'federal project') }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Street Name/Location</dt>
                            <dd class="text-sm text-slate-900">{{ $project->street ?? '123 Marine Dr' }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Area</dt>
                            <dd class="text-sm text-slate-900">{{ $project->area ?? 'Barrigada' }}</dd>
                        </div>
                       

                        {{-- NEW: Lot size + unit --}}
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Lot Size</dt>
                            <dd class="text-sm text-slate-900">
                                @if(!empty($project->lot_size))
                                    {{ number_format($project->lot_size, 2) }}
                                    @if(!empty($project->unit_of_size))
                                        <span class="text-slate-600 text-xs ml-1">{{ $project->unit_of_size }}</span>
                                    @endif
                                @else
                                    <span class="text-slate-500">—</span>
                                @endif
                            </dd>
                        </div>

                        {{-- NEW: Staff (Engineering Data) --}}
                        {{-- <div>
                            <dt class="text-xs font-medium text-slate-500">Staff (Engineering Data)</dt>
                            <dd class="text-sm text-slate-900">
                                {{ $project->staff_engineering_data ?: '—' }}
                            </dd>
                        </div>

                        {{-- NEW: Staff Initials --}}
                        {{-- <div>
                            <dt class="text-xs font-medium text-slate-500">Staff Initials</dt>
                            <dd class="text-sm text-slate-900">
                                {{ $project->staff_initials ?: '—' }}
                            </dd>
                        </div>   --}}
                    </dl>
                </div>

                <!-- SLA / Deadlines -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">

                    <h2 class="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Response Windows</h2>

                    <div class="grid grid-cols-1 gap-3 md:grid-cols-2">

                        <!-- Submitter -->
                        <div class="rounded-xl border border-slate-200 p-3">
                            <div class="flex items-center justify-between">
                                <h3 class="text-sm font-semibold text-slate-900">Submitter</h3>
                            </div>
                            <div class="mt-2 flex items-center gap-3 text-sm">
                                <div class="rounded-lg bg-slate-50 px-2.5 py-1">
                                    Due:
                                    <span class="font-medium text-slate-900">
                                        {{ $project->submitter_due_date ?? '2025-08-06 17:16:15' }}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- Reviewer -->
                        <div class="rounded-xl border border-slate-200 p-3">
                            <div class="flex items-center justify-between">
                                <h3 class="text-sm font-semibold text-slate-900">Reviewer</h3>
                            </div>
                            <div class="mt-2 flex items-center gap-3 text-sm">
                                <div class="rounded-lg bg-slate-50 px-2.5 py-1">
                                    Due:
                                    <span class="font-medium text-slate-900">
                                        {{ $project->reviewer_due_date ?? '2025-08-06 17:16:15' }}
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <!-- Audit -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
                    <h2 class="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Audit</h2>
                    <dl class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Created by</dt>
                            <dd class="text-sm text-slate-900">
                                ID {{ $project->created_by ?? 9 }} —
                                <span class="text-slate-600">{{ $project->created_at ?? '2025-08-04 07:01:06' }}</span>
                            </dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Updated by</dt>
                            <dd class="text-sm text-slate-900">
                                ID {{ $project->updated_by ?? 9 }} —
                                <span class="text-slate-600">{{ $project->updated_at ?? '2025-09-22 05:18:14' }}</span>
                            </dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Last submitted</dt>
                            <dd class="text-sm text-slate-900">
                                {{ $project->last_submitted_at ?? '—' }}
                                <span class="text-slate-600">
                                    by {{ $project->last_submitted_by ?? '—' }}
                                </span>
                            </dd>
                        </div>
                        <div>
                            <dt class="text-xs font-medium text-slate-500">Last reviewed</dt>
                            <dd class="text-sm text-slate-900">
                                {{ $project->last_reviewed_at ?? '—' }}
                                <span class="text-slate-600">
                                    by {{ $project->last_reviewed_by ?? '—' }}
                                </span>
                            </dd>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Right: Quick glance / sticky on desktop -->
            <aside class="sticky top-4 h-max space-y-4">
                <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
                    <h2 class="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Submitter Information</h2>
                    <ul class="space-y-2 text-sm text-slate-700">
                        {{-- <li class="flex items-center justify-between">
                            <span>Status</span>
                            <span class="font-medium text-slate-900">
                                {{ str_replace('_',' ', ucfirst($status)) }}
                            </span>
                        </li> --}}
                        <li class="flex items-center justify-between ">
                            <span>Name: </span>
                            <span class="font-medium text-slate-900 text-end max-w-32 text-wrap text-truncate overflow-hidden">
                                {{ $project->creator->name ?? 'NOT SET' }}
                            </span>
                        </li>
                        <li class="flex items-center justify-between ">
                            <span>Email address: </span>
                            <span class="font-medium text-slate-900 text-end max-w-32 text-wrap text-truncate overflow-hidden">
                                {{ $project->creator->email ?? 'NOT SET' }}
                            </span>
                        </li>

                        
                        <li class="flex items-center justify-between ">
                            <span>Company: </span>
                            <span class="font-medium text-slate-900 text-end max-w-32 text-wrap text-truncate overflow-hidden">
                                {{ $project->creator->company ?? 'NOT SET' }}
                            </span>
                        </li>

                        <li class="flex items-center justify-between ">
                            <span>Address: </span>
                            <span class="font-medium text-slate-900 text-end max-w-32 text-wrap text-truncate overflow-hidden">
                                {{ $project->creator->address ?? 'NOT SET' }}
                            </span>
                        </li>

                        <li class="flex items-center justify-between ">
                            <span>Phone #: </span>
                            <span class="font-medium text-slate-900 text-end max-w-32 text-wrap text-truncate overflow-hidden">
                                {{ $project->creator->phone_number ?? 'NOT SET' }}
                            </span>
                        </li>

                        


                        @if(Auth::user()->hasPermissionTo('system access global admin') || Auth::user()->hasPermissionTo('system access admin') || Auth::user()->hasPermissionTo('system access reviewer'))
                            <li class="flex items-center justify-between">
                                <span>Project #</span>
                                <span class="font-medium text-slate-900">
                                    {{ $project->project_number ?? 'PRJ-000000186' }}
                                </span>
                            </li>
                        @endif

                        {{-- <li class="flex items-center justify-between">
                            <span>RC #</span>
                            <span class="font-medium text-slate-900">
                                {{ $project->rc_number ?? 'RC-000000001' }}
                            </span>
                        </li> --}}

                        {{-- NEW: Staff initials quick glance --}}
                        {{-- <li class="flex items-center justify-between">
                            <span>Staff Initials</span>
                            <span class="font-medium text-slate-900">
                                {{ $project->staff_initials ?: '—' }}
                            </span>
                        </li> --}}

                        {{-- NEW: Boolean status badges --}}
                        {{-- <li class="flex items-center justify-between">
                            <span>Site Area Inspection</span>
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium
                                {{ $project->site_area_inspection ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600' }}">
                                {{ $project->site_area_inspection ? 'Yes' : 'No' }}
                            </span>
                        </li>

                        <li class="flex items-center justify-between">
                            <span>Burials Discovered Onsite</span>
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium
                                {{ $project->burials_discovered_onsite ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600' }}">
                                {{ $project->burials_discovered_onsite ? 'Yes' : 'No' }}
                            </span>
                        </li>

                        <li class="flex items-center justify-between">
                            <span>Certificate of Approval</span>
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium
                                {{ $project->certificate_of_approval ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600' }}">
                                {{ $project->certificate_of_approval ? 'Yes' : 'No' }}
                            </span>
                        </li>

                        <li class="flex items-center justify-between">
                            <span>Notice of Violation</span>
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium
                                {{ $project->notice_of_violation ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600' }}">
                                {{ $project->notice_of_violation ? 'Yes' : 'No' }}
                            </span>
                        </li> --}}
                    </ul>
                </div>  

                @if(Auth::user()->can('system access admin') || Auth::user()->can('system access global admin'))
                    <!-- References -->
                    <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
                        <div class="mb-3 flex items-center justify-between">
                            <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">References</h2>
                            <a href="{{ route('project.edit', ['project' => $project->id ]) }}" class="text-xs font-medium text-slate-700 hover:underline">Manage</a>
                        </div> 
                        @if(( count($projectReferences) ?? 0) === 0)
                            <p class="text-sm text-slate-600">No references.</p>
                            <div class="mt-3">
                                <a href="{{ route('project.edit', ['project' => $project->id ]) }}" class="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Add subscribers</a>
                            </div>
                        @else
                            <ul role="list" class="space-y-2">
                                @foreach($projectReferences as $index => $projectRefence)
                                    
                                    <li class="flex items-center justify-between rounded-lg border border-slate-200 p-2 relative overflow-visible">
                                        <div class="overflow-x-auto">
                                            @php
                                                $tooltipArrayMessage = [
                                                    "Project name: " =>  $projectRefence['name'],
                                                    "RC# : " =>  $projectRefence['rc_number'],
                                                    "Location: " =>  $projectRefence['location']
                                                ]; 
                                            @endphp

                                            <x-ui.project.project-reference 
                                                :name="$projectRefence['name']"
                                                :rc_number="$projectRefence['rc_number']"
                                                :location="$projectRefence['location']"
                                                displayTooltip
                                                tooltipText="Project Reference Information: "
                                                :tooltipLabelTextArrMsg="$tooltipArrayMessage"
                                            />
                                        </div>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                @endif


                <!-- Subscribers -->
                <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6">
                    <div class="mb-3 flex items-center justify-between">
                        <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Subscribers</h2>
                        <a href="{{ route('project.edit', ['project' => $project->id ]) }}" class="text-xs font-medium text-slate-700 hover:underline">Manage</a>
                    </div> 
                    @if(($project->project_subscribers->count() ?? 0) === 0)
                        <p class="text-sm text-slate-600">No one is subscribed yet.</p>
                        <div class="mt-3">
                            <a href="{{ route('project.edit', ['project' => $project->id ]) }}" class="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Add subscribers</a>
                        </div>
                    @else
                        <ul role="list" class="space-y-2">
                            @foreach($project->project_subscribers as $subscriber)
                                @php 
                                    $u = App\Models\User::find($subscriber->user_id);
                                @endphp
                                <li class="flex items-center justify-between rounded-lg border border-slate-200 p-2">
                                    <div class="flex items-center gap-3 min-w-0">
                                        <div class="grid size-8 place-content-center rounded-full bg-slate-100 text-xs font-semibold text-slate-700">
                                            {{ strtoupper(Str::of($u->name)->explode(' ')->map(fn($p)=>Str::substr($p,0,1))->take(2)->implode('')) }}
                                        </div>
                                        <div class="min-w-0">
                                            <p class="truncate text-sm font-medium text-slate-900">{{ $u->name }}</p>
                                            <p class="truncate text-xs text-slate-600">{{ $u->email }}</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <span class="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-700">{{ $u->role ?? 'Member' }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>

                

                <!-- Help Widget  -->
                    @if($project->status == "draft")
                        <livewire:components.helper-widget.project.project-submit-help-wdiget :project_id="$project->id" />
                    @elseif($project->status == "submitted" && empty($project->rc_number))
                        <livewire:components.helper-widget.project.project-r-c-number-eval-help-wdiget :project_id="$project->id" />
                    @elseif(!empty($project->rc_number))
                         <livewire:components.helper-widget.project.project-reviewed-help-wdiget :project_id="$project->id" />
                    @endif
                <!-- ./ Help widget -->







            </aside>
        </section>
    </div>


    

    
      
    <!-- Floating Loading Notification -->
    <div 
        wire:loading 
    class="fixed top-4 right-4 z-50 w-[22rem] max-w-[calc(100vw-2rem)]
            rounded-2xl border border-slate-200 bg-white shadow-lg"
    role="status"
    aria-live="polite"
    >
        <div class="flex items-start gap-3 p-4">
            <!-- Spinner -->
            <svg class="h-5 w-5 mt-0.5 animate-spin text-slate-600 shrink-0"
                viewBox="0 0 24 24" fill="none">
            <circle class="opacity-25" cx="12" cy="12" r="10"
                    stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 0 1 8-8v3a5 5 0 0 0-5 5H4z" />
            </svg>

            <!-- Text + Progress -->
            <div class="flex-1 min-w-0">
                <div class="text-sm font-semibold text-slate-900">
                    Loading data…
                </div>
                <div class="mt-0.5 text-xs text-slate-600">
                    Fetching the latest records. Please wait.
                </div>

                <!-- Indeterminate Progress Bar -->
                <div class="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                    class="absolute inset-y-0 left-0 w-1/3 rounded-full bg-slate-400"
                    style="animation: indeterminate-bar 1.2s ease-in-out infinite;"
                    ></div> 

                </div>
            </div>
        </div>
    </div>


    {{-- Loaders (unchanged) --}}
    {{-- <div wire:loading class="p-0 m-0" style="padding: 0; margin: 0;">
        <div class="absolute right-4 top-4 z-50 inline-flex items-center gap-2 px-4 py-3 rounded-md text-sm text-white bg-blue-600 border border-blue-700 shadow-md animate-pulse mb-4 mx-3">
            <div>   
                <svg class="h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                </svg>
            </div>
            <div>Loading new data, please wait...</div> 
        </div>
    </div> --}}

    <div wire:loading wire:target="submit_project">
        <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
            <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                </svg>
                <div class="text-sm font-medium">Submitting project...</div>
            </div>
        </div>
    </div>


    {{-- Do not remove --}}
    {{-- 
        Essential for getting the model id from the browser bar 
        This is to get model id for : 
        1. Full page load (hard refresh, direct URL, normal navigation)
        2. Livewire SPA navigation (wire:navigate)
    --}}
    @push('scripts')
        <script>

            (function () {

                function getData(){
                    window.pageProjectId = @json(optional(request()->route('project'))->id ?? request()->route('project') ?? null);
                    console.log(window.pageProjectId);

                    const pageProjectId = window.pageProjectId; // can be null
                    // 2) Conditionally listen to the model-scoped user channel
                    if (pageProjectId) {
                        console.log(`listening to : ${pageProjectId}`);
                        window.Echo.private(`project.${pageProjectId}`)
                            .listen('.event', (e) => {
                                console.log('[project model-scoped]');

                                let dispatchEvent = `projectEvent.${pageProjectId}`;
                                Livewire.dispatch(dispatchEvent); 

                                console.log(dispatchEvent); 

                            });
                    }
                }

                /**
                 * 1. Full page load (hard refresh, direct URL, normal navigation)
                 */
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', () => {
                        getData();
                    });
                } else {
                    // DOM already loaded
                    getData();
                }

                /**
                 * 2. Livewire SPA navigation (wire:navigate)
                 */
                document.addEventListener('livewire:navigated', () => {
                    getData();
                });

            })();
 


        </script>
    @endpush


        
    
</div>
<!-- End Card Section -->

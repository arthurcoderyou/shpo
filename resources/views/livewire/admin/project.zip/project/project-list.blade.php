<!-- Table Section -->
<div class=" px-4 py-3 sm:px-6 lg:px-8  mx-auto"
    x-data="{
        showModal: false,  
        handleKeydown(event) {
            if (event.keyCode == 191) {
                this.showModal = true; 
            }
            if (event.keyCode == 27) {
                this.showModal = false; 
                $wire.search = '';
            }

        },
        saerch_project() {
            this.showModal = false;
            {{-- $wire.search = '';  --}}
        }
    }"
>

 

    {{-- <div wire:loading style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
        <div></div>
        <div></div>
    </div> --}}


    <script src="https://cdn.jsdelivr.net/npm/@preline/remove-element@2.6.0/index.min.js"></script>
    

    <!-- Card -->
    <div class="flex flex-col">
        <div class="-m-1.5 overflow-x-auto">
        <div class="p-1.5 max-w-full w-full align-middle ">
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm  overflow-x-auto ">
            


                <!-- Header -->
                <div class="w-full   px-4 py-2 border-b border-gray-200 bg-white">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-y-2">
                        <!-- Title and Subtitle -->
                        <div>
                            <h2 class="text-xl font-semibold text-sky-900 flex items-center gap-2">
                                {{ $title }}
                                <span class="inline-flex justify-center items-center w-6 h-6 text-xs font-medium bg-black text-white rounded-full">
                                    {{ $projects_count ?? 0 }}
                                </span>
                            </h2>
                            <p class="text-sm text-gray-500">{{ $subtitle }}</p>
                        </div>

                        <!-- Action Bar -->
                        <div class="flex  flex-wrap items-center gap-2 justify-start sm:justify-end mt-2 sm:mt-0">

                            <!-- Search -->
                            <input type="text" wire:model.live="search"
                                class="min-w-[160px] px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500"
                                placeholder="Search">

                        

                            

                            <select wire:model.live="project_status" class="min-w-[140px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Project Status</option>
                                @foreach ($project_status_options as $key => $value)
                                    <option value="{{ $key }}">{{ $value }}</option>
                                @endforeach
                            </select>

                            <select wire:model.live="type" class="min-w-[120px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Project Type</option>
                                @foreach ($project_types as $type_id => $type_name)
                                    <option>{{ $type_name }}</option>
                                @endforeach
                            </select>

                            <select wire:model.live="sort_by" class="min-w-[160px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Sort By</option>
                                <option>Name A - Z</option>
                                <option>Name Z - A</option>
                                <!-- Add rest of the sort options -->
                            </select>

                            {{-- <!-- Delete Button -->
                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('system access user'))
                                <button onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                                    wire:click.prevent="deleteSelected"
                                    {{ $count == 0 ? 'disabled' : '' }}
                                    class="text-sm px-3 py-1.5 rounded-md bg-red-500 text-white hover:bg-red-600 disabled:opacity-50">
                                    Delete ({{ $count }})
                                </button>   
                            @endif --}}

                            <!-- Create Button -->
                            <a href="{{ route('project.create') }}"
                            wire:navigate
                                class="text-sm px-3 py-1.5 rounded-md bg-blue-500 text-white hover:bg-blue-600">
                                + New
                            </a>

                            {{-- <!-- Home Button -->
                            <a href="{{ $home_route }}"
                                wire:navigate
                                class="text-sm px-3 py-1.5 rounded-md bg-sky-500 text-white hover:bg-sky-600">
                                Refresh
                            </a> --}}

                        </div>
                    </div>
                </div>
                <!-- End Header -->



    
                <!-- Table -->
                <table class="w-full divide-y divide-gray-200 overflow-x-auto">
                    <thead class="bg-gray-50 ">
                    <tr>
                         
                        <th class=" w-4    px-3 py-3  ">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Actions
                                </span>
                            </div>
                        </th>
                         


                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Project Details
                                </span>
                            </div>
                        </th>

                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Type
                                </span>
                            </div>
                        </th>
 

                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Project Documents
                                </span>
                            </div>
                        </th>

                        
                    </tr>
                    </thead>

                    <tbody class="divide-y divide-gray-200 ">

                        @if(!empty($projects) && count($projects) > 0)
                            @foreach ($projects as $project)
                                <tr>

                                    <td class="w-fill text-nowrap align-top px-4 py-3   ">
                                        <div class="flex items-center justify-between space-x-2">
                                            <div class="flex items-center gap-1">
                                                 @if(Auth::user()->can('system access global admin') || Auth::user()->can('project view'))

                                                <a href="{{ route('project.show',['project' => $project->id]) }}" 
                                                    wire:navigate
                                                    class="rounded-md bg-black px-2.5 py-1 text-xs font-medium text-white">
                                                    View
                                                </a>
                                                @endif
                                                

                                                <el-dropdown class="inline-block p-0">
                                                    <button class=" inline-flex rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-50">
                                                        
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4">
                                                            <circle cx="12" cy="5" r="2" />
                                                            <circle cx="12" cy="12" r="2" />
                                                            <circle cx="12" cy="19" r="2" />
                                                        </svg>

                                                    </button>

                                                    <el-menu anchor="bottom end" popover class="m-0 w-56 origin-top-right rounded-md bg-white p-0 shadow-lg outline outline-1 outline-black/5 transition [--anchor-gap:theme(spacing.2)] [transition-behavior:allow-discrete] data-[closed]:scale-95 data-[closed]:transform data-[closed]:opacity-0 data-[enter]:duration-100 data-[leave]:duration-75 data-[enter]:ease-out data-[leave]:ease-in">
                                                        <div class="py-1">
                                                             


                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project view'))
                                                                <a 
                                                                href="{{ route('project.show',['project' => $project->id]) }}" 
                                                                wire:navigate
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            View
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.display class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif


                                                            {{-- @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create'))
                                                                <a 
                                                                href="{{ route('project.project_document.create',['project' => $project->id]) }}"
                                                                wire:navigate
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Add Project Document
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.document class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif --}}
                                                            
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create'))
                                                                <a 
                                                                href="{{ route('project.project_documents',['project' => $project->id]) }}"
                                                                wire:navigate
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            View Documents
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.document class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif
                                                            
                                                                

                                                             
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project edit'))
                                                                <a 
                                                                href="{{ route('project.edit',['project' => $project->id]) }}"
                                                                wire:navigate 
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Edit
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.edit class="text-blue-600 hover:text-blue-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif
                                                                
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project delete'))
                                                                <!-- Force Delete-->
                                                                <button
                                                                    onclick="confirm('Are you sure, you want to delete this record?') || event.stopImmediatePropagation()"
                                                                    wire:click.prevent="delete({{ $project->id }})"
                                                                    type="button"
                                                                    class="block w-full px-4 py-2 text-left text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                >   
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Delete
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.delete class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Delete" />
                                                                        </div>
                                                                    </div>

                                                                    
                                                                </button>
                                                            @endif

                                                        </div>
                                                    </el-menu>
                                                </el-dropdown>
                

                                            </div>
                                        </div>
                                    </td>


                                    

                                    <td class="max-w-32 text-nowrap align-top px-4 py-3 ">
                                        <div class="space-y-1">
                                            <p class="text-sm font-semibold text-gray-900">{{ $project->name }}</p>
                                            <p class="text-sm text-gray-500">Lot #: {{ $project->lot_number }}</p>
                                            <p class="text-sm text-gray-500 text-wrap">Location: {{ $project->location }}</p> 
                                            {{-- <p class="text-sm font-semibold text-green-700">{{ $project->type }}</p> --}}
                                        </div>
                                    </td>

                                    
                                    <td class="align-top  py-3 text-slate-700"> 
                                        {{ $project->type }}  
                                    </td>
 
                                    <td class=" text-nowrap align-top whitespace-nowrap px-4 py-3 text-sm text-gray-700">

                                        @if(!empty($project->project_documents))
                                            @foreach ($project->project_documents as $project_document)
                                                <div class="flex items-center gap-2 mb-1">
                                                    <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 ring-1 ring-slate-200">
                                                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M4 7a2 2 0 0 1 2-2h7l5 5v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M13 5v4h4"/></svg>
                                                    </div>
                                                    <div>
                                                        <a  href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                            wire:navigate 
                                                            class="font-medium text-slate-900 hover:underline">
                                                            {{ $project_document->document_type ? $project_document->document_type->name : '' }}
                                                        </a>
                                                        <div class="text-xs text-slate-500">
                                                            {{ $project_document->project_attachments ? $project_document->project_attachments->count().' attachments found' : 'No attachments found' }}
                                                        </div>
                                                        <div>

                                                            @php 
                                                                $config = $this->returnStatusConfig($project_document->status); 
                                                            @endphp
                                                            <span class="rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset {{ $config['bg'].' '.$config['text'].' '.$config['ring'] }}">
                                                                {{ $config['label'] }}
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div class="flex items-center gap-1">
                                                        <a  href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}" 
                                                            wire:navigate 
                                                            class="rounded-md border border-slate-200 px-2.5 py-1 text-xs">
                                                            View
                                                        </a> 
                                                    </div>

                                                </div>
                                            @endforeach
                                            
                                        @else
                                            <div>
                                                <a href="#" class="font-medium text-slate-900 hover:underline">No Documents Added</a> 
                                            </div>
                                        @endif




                                    </td>


 

                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <th scope="col" class="px-6 py-3 text-start">
                                    <div class="flex items-center gap-x-2">
                                        <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                        No records found
                                        </span>
                                    </div>
                                </th>
                            </tr>
                        @endif
                    </tbody>
                </table>
                <!-- End Table -->

                <!-- Footer -->
                <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-t border-gray-200 ">
                    {{ $projects->links() }}

                    <div class="inline-flex items-center gap-x-2">
                        <p class="text-sm text-gray-600 ">
                        Showing:
                        </p>
                        <div class="max-w-sm space-y-3">
                        <select wire:model.live="record_count" class="py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                            <option>10</option>
                            <option>25</option>
                            <option>50</option>
                            <option>100</option>
                            <option>200</option>
                        </select>
                        </div>
                        <p class="text-sm text-gray-600 ">
                            {{ count($projects) > 0 ? 'of '.$projects->total()  : '' }}
                        </p>
                    </div>


                </div>
                <!-- End Footer -->


            </div>
        </div>
        </div>
    </div>
    <!-- End Card -->

 
 

    <script>
        function copyLocationToClipboard(textToCopy) {
            // Create a temporary textarea to hold the text
            let tempInput = document.createElement("textarea");
            tempInput.value = textToCopy;
            document.body.appendChild(tempInput);

            // Select and copy the text
            tempInput.select();
            document.execCommand("copy");

            // Remove the temporary input
            document.body.removeChild(tempInput);

            // Provide user feedback (optional)
            alert("Copied to clipboard: " + textToCopy);
        }
    </script>


    <!--  Loaders -->
        {{-- wire:target="table"   --}}
        <div wire:loading 
            class="p-0 m-0"
            style="padding: 0; margin: 0;">
            <div class="absolute right-4 top-4 z-10 inline-flex items-center gap-2 px-4 py-3 rounded-md text-sm text-white bg-blue-600 border border-blue-700 shadow-md animate-pulse mb-4 mx-3">
                <div>   
                    <svg class="h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                    </svg>
                </div>
                <div>
                    Loading lists, please wait...
                </div> 
            </div>
        </div>

        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>

        {{-- wire:target="delete"   --}}
        <div wire:loading  wire:target="delete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>
        


        

        {{-- wire:target="executeForceDelete"   --}}
        <div wire:loading  wire:target="executeForceDelete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>


        
        {{-- wire:target="executeRecover"   --}}
        <div wire:loading  wire:target="executeRecover"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Recovering record...
                    </div>
                </div>
            </div>

            
        </div>



    <!-- ./  Loaders -->


</div>
<!-- End Table Section -->

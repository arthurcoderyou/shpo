<!-- Table Section -->
<div class=" px-4 py-3 sm:px-6 lg:px-8  mx-auto"
    x-data="{
        statusFilter: @entangle('review_status') ,
        projectFilter: @entangle('project_status') ,
        pendingRcStatusFilter: @entangle('pending_rc_number'),
        showModal: false,  
        handleKeydown(event) {
            if (event.keyCode == 191) {
                this.showModal = true; 
            }
            if (event.keyCode == 27) {
                this.showModal = false; 
                $wire.search = '';
            }

        },
        saerch_project() {
            this.showModal = false;
            {{-- $wire.search = '';  --}}
        },
        syncAll() {
            const isAll =
                $wire.review_status === null &&
                $wire.project_status === null &&
                ($wire.pending_rc_number === false || $wire.pending_rc_number === 0 || $wire.pending_rc_number === '0');

            statusFilter = isAll ? 'all' : null;
        }      

    }"

    x-init="
        syncAll();

        // Recompute whenever Livewire changes these values
        $watch('$wire.review_status', () => syncAll());
        $watch('$wire.project_status', () => syncAll());
        $watch('$wire.pending_rc_number', () => syncAll());
    "

 

>

 

    {{-- <div wire:loading style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
        <div></div>
        <div></div>
    </div> --}}


    <script src="https://cdn.jsdelivr.net/npm/@preline/remove-element@2.6.0/index.min.js"></script>
    

    <!-- Card -->
    <div class="flex flex-col">
        <div class="-m-1.5 overflow-x-auto">
        <div class="p-1.5 max-w-full w-full align-middle ">

 


            <!-- Header -->
            <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-2 max-w-full overflow-x-auto">
                <div class="flex items-center"> 
                    <button 
                        @click="pendingRcStatusFilter = !pendingRcStatusFilter; $wire.set('pending_rc_number', pendingRcStatusFilter);"
                        :class="pendingRcStatusFilter ? 'bg-red-500 text-white' : 'bg-white text-red-600 border border-red-300'"
                        class="text-nowrap px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                    >
                        Pending RC Number
 
                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="pendingRcStatusFilter ? 'bg-white text-red-800' : 'bg-red-100 text-red-700'"
                            x-text="$wire.count_pending_rc_number"
                        ></span>
                    </button>

                </div>

                <!-- Filter Buttons -->
                <div class="flex space-x-2 mt-3 sm:mt-0">
                    <button 
                        @click="
                            
                            pendingRcStatusFilter = false; 
                            $wire.set('review_status', 'all');
                            $wire.set('project_status', null);
                            $wire.set('pending_rc_number', false);
                            statusFilter = 'all';
                        "
                        :class="statusFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-white text-slate-700 border'"
                        class="text-nowrap relative px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                    >
                        <span>All</span>
                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="statusFilter === 'all' ? 'bg-white text-slate-800' : 'bg-slate-100 text-slate-700'"
                            x-text="$wire.count_all"
                        ></span>
                    </button>


                    @if(Auth::user()->hasPermissionTo('system access admin'))
                    <button  
                        @click="
                            projectFilter = (projectFilter === 'on_que') ? null : 'on_que';
                            $wire.set('project_status', projectFilter);
                        "
                        :class="projectFilter === 'on_que' ? 'bg-slate-500 text-white' : 'bg-white text-slate-600 border border-slate-300'"
                        class="text-nowrap px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                    >
                        <span class="hidden lg:block">On Queue</span>  <!-- For Desktop view-->
                        <span class="block lg:hidden">Que</span>    <!-- For Mobile view--> 

                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="projectFilter === 'on_que' ? 'bg-white text-slate-800' : 'bg-slate-100 text-slate-700'"
                            x-text="$wire.count_on_que"
                        ></span>

                    </button>
                    @endif



                    @if(Auth::user()->hasPermissionTo('system access admin'))
                    <button 
                        @click="statusFilter = 'open_review', $wire.set('review_status', 'open_review')"
                        :class="statusFilter === 'open_review' ? 'bg-lime-500 text-white' : 'bg-white text-lime-600 border border-lime-300'"
                        class="text-nowrap px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                    >
                        
                        <span class="hidden lg:block">Open Review</span>  <!-- For Desktop view-->
                        <span class="block lg:hidden">Open</span>    <!-- For Mobile view--> 

                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="statusFilter === 'open_review' ? 'bg-white text-lime-800' : 'bg-lime-100 text-lime-700'"
                            x-text="$wire.count_open_review"
                        ></span>

                    </button>
                    @endif

                    <button 
                        @click="statusFilter = 'changes_requested', $wire.set('review_status', 'changes_requested')"
                        :class="statusFilter === 'changes_requested' ? 'bg-violet-500 text-white' : 'bg-white text-violet-600 border border-violet-300'"
                        class="text-nowrap px-3 py-1 rounded-lg text-sm font-medium transition flex items-center space-x-1"
                    >
                        
                        <span class="hidden lg:block">Changes Requested</span>  <!-- For Desktop view-->
                        <span class="block lg:hidden">Changes</span>    <!-- For Mobile view--> 

                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="statusFilter === 'changes_requested' ? 'bg-white text-violet-800' : 'bg-violet-100 text-violet-700'"
                            x-text="$wire.count_changes_requested"
                        ></span>

                    </button>

                     <button 
                        @click="statusFilter = 'pending', $wire.set('review_status', 'pending')"
                        :class="statusFilter === 'pending' ? 'bg-blue-500 text-white' : 'bg-white text-blue-600 border border-blue-300'"
                        class="text-nowrap px-3 py-1 rounded-lg text-sm font-medium transition  flex items-center space-x-1"
                    >
                        
                        <span class="hidden lg:block">Pending Review</span>  <!-- For Desktop view-->
                        <span class="block lg:hidden">Pending</span>    <!-- For Mobile view--> 

                        <span 
                            class="ml-2 text-xs font-semibold px-2 py-0.5 rounded-full"
                            :class="statusFilter === 'pending' ? 'bg-white text-blue-800' : 'bg-blue-100 text-blue-700'"
                            x-text="$wire.count_pending"
                        ></span>

                    </button>  

                   


                    {{-- <button 
                        @click="statusFilter = 'approved'"
                        :class="statusFilter === 'approved' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-600 border border-emerald-300'"
                        class="px-3 py-1 rounded-lg text-sm font-medium transition"
                    >
                        Approved
                    </button> --}}
                </div>
            </div>



            <div class="bg-white border border-gray-200 rounded-xl shadow-sm  overflow-x-auto ">
            


                <!-- Header -->
                <div class="w-full   px-4 py-2 border-b border-gray-200 bg-white">
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-y-2">
                        <!-- Title and Subtitle -->
                        <div>
                            <h2 class="text-md font-semibold text-sky-900 flex items-center gap-2">
                                {{ $title }}
                                <span class="inline-flex justify-center items-center w-6 h-6 text-xs font-medium bg-black text-white rounded-full">
                                    {{ $projects_count ?? 0 }}
                                </span>
                            </h2>
                            <p class="text-sm text-gray-500">{{ $subtitle }}</p>
                        </div>

                        <!-- Action Bar -->
                        <div class="flex  flex-wrap items-center gap-2 justify-start sm:justify-end mt-2 sm:mt-0">

                            <!-- Search -->
                            <input type="text" wire:model.live="search"
                                class="min-w-[160px] px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:border-blue-500 focus:ring-blue-500"
                                placeholder="Search"> 

                            <select wire:model.live="project_status" class="min-w-[140px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Project Status</option>
                                @foreach ($project_status_options as $key => $value)
                                    <option value="{{ $key }}">{{ $value }}</option>
                                @endforeach
                            </select>

                            <select wire:model.live="type" class="min-w-[120px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Project Type</option>
                                @foreach ($project_types as $type_id => $type_name)
                                    <option>{{ $type_name }}</option>
                                @endforeach
                            </select>

                            <select wire:model.live="sort_by" class="min-w-[160px] text-sm py-1.5 px-2 border rounded-md">
                                <option value="">Sort By</option>
                                <option>Name A - Z</option>
                                <option>Name Z - A</option>
                                <!-- Add rest of the sort options -->
                            </select>

                            {{-- <!-- Delete Button -->
                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('system access user'))
                                <button onclick="confirm('Are you sure?') || event.stopImmediatePropagation()"
                                    wire:click.prevent="deleteSelected"
                                    {{ $count == 0 ? 'disabled' : '' }}
                                    class="text-sm px-3 py-1.5 rounded-md bg-red-500 text-white hover:bg-red-600 disabled:opacity-50">
                                    Delete ({{ $count }})
                                </button>   
                            @endif --}}

                            <!-- Create Button -->
                            <a href="{{ route('project.create') }}"
                            wire:navigate
                                class="text-sm px-3 py-1.5 rounded-md bg-blue-500 text-white hover:bg-blue-600">
                                + New
                            </a>

                            {{-- <!-- Home Button -->
                            <a href="{{ $home_route }}"
                                wire:navigate
                                class="text-sm px-3 py-1.5 rounded-md bg-sky-500 text-white hover:bg-sky-600">
                                Refresh
                            </a> --}}

                        </div>
                    </div>
                </div>
                <!-- End Header -->



    
                <!-- Table -->
                <table class="w-full divide-y divide-gray-200 overflow-x-auto">
                    <thead class="bg-gray-50 ">
                    <tr>
                         
                        <th class=" w-4    px-3 py-3  ">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Actions
                                </span>
                            </div>
                        </th>
                         


                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Project Details
                                </span>
                            </div>
                        </th>

                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Type
                                </span>
                            </div>
                        </th>
 

                        <th scope="col" class="px-2 py-3 text-start">
                            <div class="flex items-center gap-x-2">
                                <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                Project Documents
                                </span>
                            </div>
                        </th>

                        
                    </tr>
                    </thead>

                    {{-- LOADING BODY (shown only while those actions run) --}}
                    <tbody
                        class="divide-y divide-slate-200"
                        wire:loading
                        wire:target="search,project_status,remove,review_status,pending_rc_number"
                    >
                        {{-- optional single-row announcement for screen readers --}}
                        <tr>
                            <td colspan="4" class="sr-only" role="status">Loading data…</td>
                        </tr>

                        

                        {{-- skeleton rows --}}
                        @for ($i = 0; $i < max(min(count($projects), 6), 3); $i++)
                        <tr class="bg-white">
                            <td class="px-4 py-3">
                                <div class="h-4 w-10 rounded animate-pulse bg-slate-200"></div>
                            </td>
                         

                            <td class="px-4 py-3">
                                <div class="h-4 w-48 rounded animate-pulse bg-slate-200 mb-1"></div>
                                <div class="h-3 w-24 rounded animate-pulse bg-slate-100"></div>
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex gap-2">
                                    <div class="h-5 w-16 rounded-full animate-pulse bg-slate-200"></div>
                                    <div class="h-5 w-14 rounded-full animate-pulse bg-slate-200"></div>
                                    <div class="h-5 w-20 rounded-full animate-pulse bg-slate-200 hidden sm:block"></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-right">
                                <div class="inline-flex items-center gap-2">
                                    <div class="h-8 w-20 rounded-lg animate-pulse bg-slate-200"></div>
                                </div>
                            </td>
                        </tr>
                        @endfor
                    </tbody>




                    <tbody
                    wire:loading.remove
                    wire:target="search,project_status,remove,review_status,pending_rc_number"
                    class="divide-y divide-gray-200 ">

                        @if(!empty($projects) && count($projects) > 0)
                            @foreach ($projects as $project)
                                <tr>

                                    <td class="w-fill text-nowrap align-top px-4 py-3   ">
                                        <div class="flex items-center justify-between space-x-2">
                                            <div class="flex items-center gap-1">
                                                 
                                                @if(
                                                
                                                    (   
                                                        (
                                                            Auth::user()->can('system access global admin') || Auth::user()->can('project view')
                                                            
                                                        )
                                                        && 
                                                        $review_status == "open_review")

                                                        &&
                                                        !Auth::user()->can('system access user'
                                                    )


                                                )
                                                    <button 
                                                        onclick="confirm('Are you sure you want to open this project for review? If you proceed, you will be assigned as the official reviewer.') || event.stopImmediatePropagation()"
                                                        wire:click.prevent="open_review_project({{ $project->id }})"
                                                        type="button"
                                                        class="rounded-md bg-lime-500 px-2.5 py-1 text-xs font-medium text-white">
                                                        Review
                                                    </button>

                                                    
                                                @elseif(
                                                    (
                                                        Auth::user()->can('system access global admin') || Auth::user()->can('project view')
                                                    )
                                                    && $review_status == "pending" && 
                                                    !Auth::user()->can('system access user')
                                                )
                                                    <a 
                                                        href="{{ route('project.review',['project' => $project->id]) }}"
                                                        
                                                        wire:navigate
                                                        class="rounded-md bg-blue-500 px-2.5 py-1 text-xs font-medium text-white">
                                                        Review
                                                    </a> 
                                                @elseif(
                                                    (Auth::user()->can('system access global admin') || Auth::user()->can('project view')) && $project->status == "draft"
                                                )

                                                    <button 
                                                        onclick="confirm('Are you sure you want to submit this project for administrative review?') || event.stopImmediatePropagation()"

                                                        wire:click.prevent="submit_project_for_rc_evaluation({{ $project->id }})"
                                                        type="button"
                                                        class="rounded-md bg-blue-500 px-2.5 py-1 text-xs font-medium text-white">
                                                        Submit
                                                    </button>
                                                 @elseif(
                                                    (Auth::user()->can('system access global admin') || Auth::user()->can('project view')) && $project->status == "on_que"
                                                )
                                                        
                                                    <button 
                                                        onclick="confirm('Are you sure you want to force submit this project for administrative review?') || event.stopImmediatePropagation()"

                                                        wire:click.prevent="force_submit_project_for_rc_evaluation({{ $project->id }})"
                                                        type="button"
                                                        class="rounded-md bg-blue-500 px-2.5 py-1 text-xs font-medium text-white">
                                                        Force Submit
                                                    </button>

                                                @elseif(
                                                    Auth::user()->can('system access global admin') || Auth::user()->can('project view')
                                                )

                                                    <a href="{{ route('project.show',['project' => $project->id]) }}" 
                                                        wire:navigate
                                                        class="rounded-md bg-black px-2.5 py-1 text-xs font-medium text-white">
                                                        View
                                                    </a>
                                                @endif
                                                

                                                <el-dropdown class="inline-block p-0">
                                                    <button class=" inline-flex rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-50">
                                                        
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4">
                                                            <circle cx="12" cy="5" r="2" />
                                                            <circle cx="12" cy="12" r="2" />
                                                            <circle cx="12" cy="19" r="2" />
                                                        </svg>

                                                    </button>

                                                    <el-menu anchor="bottom end" popover class="m-0 w-56 origin-top-right rounded-md bg-white p-0 shadow-lg outline outline-1 outline-black/5 transition [--anchor-gap:theme(spacing.2)] [transition-behavior:allow-discrete] data-[closed]:scale-95 data-[closed]:transform data-[closed]:opacity-0 data-[enter]:duration-100 data-[leave]:duration-75 data-[enter]:ease-out data-[leave]:ease-in">
                                                        <div class="py-1">
                                                             

                                                            
                                                            
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project view'))
                                                                <a 
                                                                href="{{ route('project.show',['project' => $project->id]) }}" 
                                                                wire:navigate
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            View
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.display class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif


                                                            @if( (Auth::user()->can('system access global admin') || Auth::user()->can('project view')) && $project->status == "draft" )


                                                                <button
                                                                    onclick="confirm('Are you sure you want to submit this project for administrative review?') || event.stopImmediatePropagation()"

                                                                    wire:click.prevent="submit_project_for_rc_evaluation({{ $project->id }})"
                                                                    type="button"
                                                                    class="block w-full px-4 py-2 text-left text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                >   
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Submit
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.submit class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Submit" />
                                                                        </div>
                                                                    </div>

                                                                    
                                                                </button>

                                                            @endif
                                                            
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create'))
                                                                <a 
                                                                href="{{ route('project.project_documents',['project' => $project->id]) }}"
                                                                wire:navigate
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            View Documents
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.document class="text-gray-600 hover:text-gray-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif
                                                            
                                                                

                                                             
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project edit'))
                                                                <a 
                                                                href="{{ route('project.edit',['project' => $project->id]) }}"
                                                                wire:navigate 
                                                                class="block px-4 py-2 text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none">
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Edit
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.edit class="text-blue-600 hover:text-blue-700 size-4 shrink-0" title="Edit" />
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            @endif
                                                                
                                                            @if(Auth::user()->can('system access global admin') || Auth::user()->can('project delete'))
                                                                <!-- Force Delete-->
                                                                <button
                                                                    onclick="confirm('Are you sure, you want to delete this record?') || event.stopImmediatePropagation()"
                                                                    wire:click.prevent="delete({{ $project->id }})"
                                                                    type="button"
                                                                    class="block w-full px-4 py-2 text-left text-sm text-gray-700 focus:bg-gray-100 focus:text-gray-900 focus:outline-none"
                                                                >   
                                                                    <div class="flex justify-between items-center">
                                                                        <div>
                                                                            Delete
                                                                        </div>

                                                                        <div>
                                                                            <x-svg.delete class="text-red-600 hover:text-red-700 size-4 shrink-0" title="Delete" />
                                                                        </div>
                                                                    </div>

                                                                    
                                                                </button>
                                                            @endif

                                                        </div>
                                                    </el-menu>
                                                </el-dropdown>
                

                                            </div>
                                        </div>
                                    </td>


                                    

                                    <td class="max-w-32 text-wrap align-top px-4 py-3 ">
                                        <div class="space-y-1">
                                            <p class="text-sm font-semibold text-gray-900">{{ $project->name }}</p>
                                            <div class="flex items-center gap-x-2 py-2">
                                                <span class="text-sm font-medium text-gray-700 text-nowrap">
                                                    Project Status:
                                                </span>

                                                <span class="text-sm text-nowrap">  

                                                    @php 
                                                        $config = $this->returnStatusConfig($project->status); 
                                                    @endphp
                                                    <span class="rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset {{ $config['bg'].' '.$config['text'].' '.$config['ring'] }}">
                                                        {{ $config['label'] }}
                                                    </span>
                                                    
                                                    {{-- {!! $project->getStatus() !!} --}}
                                                </span>
                                            </div>
                                            <p class="text-sm text-gray-500">Lot #: {{ $project->lot_number }}</p>
                                            <p class="text-sm text-gray-500 text-wrap">Location: {{ $project->location }}</p> 
                                            {{-- <p class="text-sm font-semibold text-green-700">{{ $project->type }}</p> --}}
                                        </div>
                                    </td>

                                    
                                    <td class="align-top  py-3 text-slate-700"> 
                                        {{ $project->type }}  
                                    </td>
 
                                    <td class="max-w-96 text-wrap align-top whitespace-nowrap px-4 py-3 text-sm text-gray-700">

                                        @if(!empty($project->project_documents) && count($project->project_documents) > 0)
                                            @foreach ($project->project_documents as $project_document)
                                                <div class="flex items-center gap-2 mb-1">
                                                    <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-50 ring-1 ring-slate-200">
                                                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor"><path d="M4 7a2 2 0 0 1 2-2h7l5 5v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M13 5v4h4"/></svg>
                                                    </div>
                                                    <div>
                                                        <a  href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                            wire:navigate 
                                                            class="font-medium text-slate-900 hover:underline">
                                                            {{ $project_document->document_type ? $project_document->document_type->name : '' }}
                                                        </a>
                                                        <div class="text-xs text-slate-500">
                                                            {{ $project_document->project_attachments ? $project_document->project_attachments->count().' attachments found' : 'No attachments found' }}
                                                        </div>
                                                        <div>

                                                            @php 
                                                                $config = $this->returnStatusConfig($project_document->status); 
                                                            @endphp
                                                            <span class="rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset {{ $config['bg'].' '.$config['text'].' '.$config['ring'] }}">
                                                                {{ $config['label'] }}
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div class="flex items-center gap-1">
                                                        <a  href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}" 
                                                            wire:navigate 
                                                            class="rounded-md border border-slate-200 px-2.5 py-1 text-xs">
                                                            View
                                                        </a> 
                                                    </div>

                                                </div>
                                            @endforeach
                                            
                                       @elseif  ($project->status === 'draft') 
                                            <div>
                                                <span class="font-medium text-slate-900 ">
                                                    Your project must first be submitted for administrator review before documents can be uploaded. 
                                                    Please submit your project for admin review.
                                                </span>
                                            </div>

                                        @elseif  (empty($project->rc_number))
                                            <div>
                                                <span class="font-medium text-slate-900 ">
                                                    Your project is currently under <strong class="text-blue-500">administrative review</strong>. 
                                                    Please wait for the administrator’s approval before adding documents.
                                                </span>
                                            </div>
                                        @else
                                            <div>
                                                <span class="font-medium text-slate-900 ">No Documents Added</a> 
                                            </div>
                                        @endif




                                    </td>


 

                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <th scope="col" colspan="4" class="px-6 py-3 text-start">
                                    <div class="flex items-center gap-x-2">
                                        <span class="text-xs font-semibold uppercase tracking-wide text-gray-800 ">
                                        No records found
                                        </span>
                                    </div>
                                </th>
                            </tr>
                        @endif
                    </tbody>
                </table>
                <!-- End Table -->

                <!-- Footer -->
                <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-t border-gray-200 ">
                    {{ $projects->links() }}

                    <div class="inline-flex items-center gap-x-2">
                        <p class="text-sm text-gray-600 ">
                        Showing:
                        </p>
                        <div class="max-w-sm space-y-3">
                        <select wire:model.live="record_count" class="py-2 px-3 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 ">
                            <option>10</option>
                            <option>25</option>
                            <option>50</option>
                            <option>100</option>
                            <option>200</option>
                        </select>
                        </div>
                        <p class="text-sm text-gray-600 ">
                            {{ count($projects) > 0 ? 'of '.$projects->total()  : '' }}
                        </p>
                    </div>


                </div>
                <!-- End Footer -->


            </div>
        </div>
        </div>
    </div>
    <!-- End Card -->

 
 

    <script>
        function copyLocationToClipboard(textToCopy) {
            // Create a temporary textarea to hold the text
            let tempInput = document.createElement("textarea");
            tempInput.value = textToCopy;
            document.body.appendChild(tempInput);

            // Select and copy the text
            tempInput.select();
            document.execCommand("copy");

            // Remove the temporary input
            document.body.removeChild(tempInput);

            // Provide user feedback (optional)
            alert("Copied to clipboard: " + textToCopy);
        }
    </script>


    <!--  Loaders -->
       <!-- Floating Loading Notification -->
        <div 
            wire:loading 
        class="fixed top-4 right-4 z-50 w-[22rem] max-w-[calc(100vw-2rem)]
                rounded-2xl border border-slate-200 bg-white shadow-lg"
        role="status"
        aria-live="polite"
        >
            <div class="flex items-start gap-3 p-4">
                <!-- Spinner -->
                <svg class="h-5 w-5 mt-0.5 animate-spin text-slate-600 shrink-0"
                    viewBox="0 0 24 24" fill="none">
                <circle class="opacity-25" cx="12" cy="12" r="10"
                        stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor"
                        d="M4 12a8 8 0 0 1 8-8v3a5 5 0 0 0-5 5H4z" />
                </svg>

                <!-- Text + Progress -->
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-semibold text-slate-900">
                        Loading data…
                    </div>
                    <div class="mt-0.5 text-xs text-slate-600">
                        Fetching the latest records. Please wait.
                    </div>

                    <!-- Indeterminate Progress Bar -->
                    <div class="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div
                        class="absolute inset-y-0 left-0 w-1/3 rounded-full bg-slate-400"
                        style="animation: indeterminate-bar 1.2s ease-in-out infinite;"
                        ></div> 

                    </div>
                </div>
            </div>
        </div>

        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="z-50 bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>

        {{-- wire:target="delete"   --}}
        <div wire:loading  wire:target="delete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="z-50 bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>
        


        

        {{-- wire:target="executeForceDelete"   --}}
        <div wire:loading  wire:target="executeForceDelete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="z-50 bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Deleting record...
                    </div>
                </div>
            </div>

            
        </div>


        
        {{-- wire:target="executeRecover"   --}}
        <div wire:loading  wire:target="executeRecover"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="z-50 bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Recovering record...
                    </div>
                </div>
            </div>

            
        </div>



    <!-- ./  Loaders -->


</div>
<!-- End Table Section -->

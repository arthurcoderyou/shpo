<!-- Card Section -->
<div class="  p-4 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2"
    x-data="{ selectedRecordId: null }"
>
   
 
 
    <div class=" col-span-12  "   >
        
        <!-- Project Documents List -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 mb-6 space-y-6">
            
            <!-- Project Documents List -->
            <div class="space-y-2">
                <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                    Project Documents   
                </label>

                @if(!empty($project->project_documents) && $project->project_documents->count())
                    <ul class="divide-y divide-gray-200 border border-gray-200 rounded-lg overflow-hidden bg-white">
                        @foreach ($project->project_documents as $project_document)
                            <li class="px-4 py-4 sm:px-6 hover:bg-gray-50 transition flex items-start justify-between">
                                <div>
                                    <p class="text-base font-semibold text-gray-800">
                                        {{ $project_document->document_type->name }}
                                    </p>
                                    <p class="text-sm text-gray-600">
                                        {{ $project_document->project_attachments->count() }} attachment{{ $project_document->project_attachments->count() !== 1 ? 's' : '' }} found
                                    </p>
                                    <p class="text-xs text-gray-500 mt-1">
                                        Last updated {{ $project_document->updated_at->diffForHumans() }}
                                    </p>

                                    <p class="text-xs text-gray-500 mt-1">
                                            {{ $project_document->last_submitted_at ? "Last submitted ".$project_document->last_submitted_at->diffForHumans() : "Not Submitted Yet" }}
                                    </p>

                                </div>

                                <div class="flex flex-col items-end gap-1 text-sm whitespace-nowrap">

                                    @if(
                                        Auth::user()->can('system access global admin') || Auth::user()->can('system access admin') || 
                                        (Auth::user()->can('system access user') && $project->created_by == Auth::id() && Auth::user()->can('project document edit') )
                                    )   

                                        <button type="button"
                                            onclick="confirm('Are you sure you want to submit this document?') || event.stopImmediatePropagation()"
                                            wire:click.prevent="delete({{ $project_document->id }})"
                                            class="text-green-600 hover:underline hover:text-green-800 flex items-center gap-x-1">
                                            Submit
                                            <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path d="m9 18 6-6-6-6" />
                                            </svg>
                                        </button>


                                        {{-- @if($project->allow_project_submission == true) --}}
                                            <a target="_blank" href="{{ route('project.project_document.edit_attachments', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                wire:navigate
                                            class="text-blue-600 hover:underline hover:text-blue-800 flex items-center gap-x-1">
                                                Update
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </a>
                                        {{-- @else --}}
                                            <a target="_blank" href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                                wire:navigate
                                            class="text-gray-600 hover:underline hover:text-gray-800 flex items-center gap-x-1">
                                                View
                                                <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path d="m9 18 6-6-6-6" />
                                                </svg>
                                            </a>


                                        {{-- @endif --}}

                                        <button type="button"
                                            {{-- onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()"
                                            wire:click.prevent="delete({{ $project_document->id }})" --}}

                                            wire:click="confirmDelete({{ $project_document->id }})"

                                            class="text-red-600 hover:underline hover:text-red-800 flex items-center gap-x-1">
                                            Delete
                                            <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path d="m9 18 6-6-6-6" />
                                            </svg>
                                        </button>

                                    @else 

                                        <a target="_blank" href="{{ route('project.project-document.show', ['project' => $project->id, 'project_document' => $project_document->id]) }}"
                                            wire:navigate
                                        class="text-gray-600 hover:underline hover:text-gray-800 flex items-center gap-x-1">
                                            View
                                            <svg class="size-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path d="m9 18 6-6-6-6" />
                                            </svg>
                                        </a>


                                    @endif 


                                </div>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <!-- No documents -->
                    <div class="p-4 border border-dashed border-gray-300 rounded-md bg-gray-50 text-center text-sm text-gray-500">
                        No project documents available yet.
                    </div>
                @endif


                @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create'))
                    <div  >
                        <!-- Add new project document -->
                        <a href="{{ route('project.project-document.create',['project' => $project->id]) }}"
                                wire:navigate 
                                target="_blank" class="py-1 px-2 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border  bg-blue-500 text-white hover:bg-blue-700 focus:outline-hidden focus:border-blue-400  disabled:opacity-50 disabled:pointer-events-none">
                            Add new project document
                        </a>
                        <!-- Add new project document -->

                    </div>
                @endif


            </div>




 








        </div> 

    </div>
 
    
 

    <!--  Loaders -->
        {{-- wire:target="table"   --}}
        <div wire:loading 
            class="p-0 m-0"
            style="padding: 0; margin: 0;">
            <div class="absolute right-4 top-4 z-50 inline-flex items-center gap-2 px-4 py-3 rounded-md text-sm text-white bg-blue-600 border border-blue-700 shadow-md animate-pulse mb-4 mx-3">
                <div>   
                    <svg class="h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                    </svg>
                </div>
                <div>
                    Loading new data, please wait...
                </div> 
            </div>
        </div>

        {{-- wire:target="submit_project"   --}}
        <div wire:loading  wire:target="submit_project"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Submitting project...
                    </div>
                </div>
            </div>

            
        </div>
        

        {{-- wire:target="confirmDelete"   --}}
        <div  wire:loading wire:target="confirmDelete"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Loading...
                    </div>
                </div>
            </div>

            
        </div>


    <!-- ./  Loaders -->

    @if($confirmingDelete)
        <form wire:submit.prevent="executeDelete" class="fixed inset-0 z-40 flex items-center justify-center bg-black bg-opacity-50">
            <div class="bg-white rounded-xl shadow-xl p-6 w-full max-w-md">
                <h2 class="text-lg font-semibold text-red-600">Confirm Deletion</h2>
                <p class="text-sm text-gray-700 mt-2">
                    This action <strong>cannot be undone</strong>. Please enter your password to confirm.
                </p>

                <div class="mt-4" x-data="{ show: false }">
                    <label for="passwordConfirm" class="block text-sm font-medium text-gray-700">Your Password</label>
                    <div class="relative mt-1">
                        <input :type="show ? 'text' : 'password'" wire:model.defer="passwordConfirm" id="passwordConfirm"
                            class="block w-full rounded-md border-gray-300 pr-10 shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                        <button type="button"
                                x-on:click="show = !show"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-sm text-gray-600 hover:text-gray-900 focus:outline-none"
                                tabindex="-1">
                            <svg x-show="!show" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.478 0-8.268-2.943-9.542-7z"/>
                            </svg>
                            <svg x-show="show" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7a10.045 10.045 0 014.724-5.735M6.182 6.182l11.636 11.636M17.818 17.818L6.182 6.182"/>
                            </svg>
                        </button>
                    </div>
                    @if($passwordError)
                        <p class="text-sm text-red-500 mt-1">{{ $passwordError }}</p>
                    @endif
                </div>

                <div class="mt-6 flex justify-end space-x-2">
                    <button wire:click="$set('confirmingDelete', false)"
                            type="button"
                            class="px-4 py-2 text-sm rounded-md border border-gray-300 text-gray-700 bg-white hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-4 py-2 text-sm rounded-md text-white bg-red-600 hover:bg-red-700">
                        Confirm Delete
                    </button>
                </div>
            </div>
        </form>
    @endif


    




</div>
<!-- End Card Section -->

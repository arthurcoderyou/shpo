<!-- Card Section --> 
<div   class="  p-4 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
     

     
    {{-- <div wire:loading class="loading-overlay"> --}}
        {{-- <div wire:loading style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
            <div></div>
            <div></div>
        </div> --}}
    {{-- </div> --}}
     
 
    <form class="col-span-12  " wire:submit="save">
        <!-- Card -->
        <div class="bg-white rounded-2xl border border-slate-200 ">


            <div class="  p-4 space-y-2">

                {{-- <div class="sm:col-span-12">
                    <h2 class="text-lg font-semibold text-gray-800 ">
                        Submit new project
                    </h2>
                </div>
                <!-- End Col --> --}}


                 



                <!-- Grid -->
                <div class="grid grid-cols-12 gap-2  ">

                    <div class="space-y-2 col-span-12   ">
                        <x-ui.project.project-relative-search 
                            id="name"
                            name="name"
                            type="text"
                            wire:model.live="name"   
                            label="Project Title"
                            required  
                            placeholder="Enter project title" 
                            :error="$errors->first('name')"
                            :warning="isset($warnings['name']) ? $warnings['name'][0] : null"


                            displayTooltip
                            position="top"
                            tooltipText="Please enter the official name of the project." 
 
                           :options="$projects"
                        />


                    </div> 
                     

                     <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        
                        <x-ui.input 
                            id="lot_number"
                            name="lot_number"
                            type="text"
                            wire:model.live="lot_number"   
                            label="Lot number"
                              
                            placeholder="Enter Lot number" 
                            :error="$errors->first('lot_number')"
 
                            displayTooltip
                            position="top"
                            tooltipText="Please enter the lot number of the project." 
                        />

                    </div>

                   
                    
                    <div class="space-y-2 col-span-12 sm:col-span-4   ">
                         
                        @if($type == "Federal Government")
                            <x-ui.input 
                                id="installation"
                                name="installation"
                                type="text"
                                wire:model.live="installation"   
                                label="Installation"
                                required  
                                placeholder="Enter installation location" 
                                :error="$errors->first('installation')"
    
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the installation location of the project." 
                            />
                        @else

                            <x-ui.input 
                                id="location"
                                name="location"
                                type="text"
                                wire:model.live="location"   
                                label="Street Name/Location"
                                required  
                                placeholder="Enter location" 
                                :error="$errors->first('location')"
    
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the location of the project." 
                            />
                        @endif


                    </div> 


                    

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        

                        

                        @if($type == "Federal Government")
                            <x-ui.input 
                                id="sub_area"
                                name="sub_area"
                                type="text"
                                wire:model.live="sub_area"   
                                label="Sub-Area"
                                required  
                                placeholder="Enter Sub-Area" 
                                :error="$errors->first('sub_area')"
    
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the sub-area of the project." 
                            />
                        @else

                            <x-ui.input 
                                id="area"
                                name="area"
                                type="text"
                                wire:model.live="area"   
                                label="Area/Village"
                                required  
                                placeholder="Enter Area" 
                                :error="$errors->first('area')"
    
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the area of the project." 
                            />
                        @endif




                    </div>




                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        
                        

                        <x-ui.select
                            id="type"
                            name="type"
                            label="Type"
                            wire:model.live="type"  
                            required="" 
                            placeholder="Select a type" 
                            :error="$errors->first('type')"
                            :options="$project_types"
  
                            displayTooltip
                            position="top"
                            tooltipText="Please enter the type of the project."
 

                        />



                    </div>

                     
                   

                    
                     @if($type == "Federal Government")
                     <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        
                            <x-ui.input 
                                id="project_size"
                                name="project_size"
                                type="number"
                                wire:model.live="project_size"   
                                label="Project size"
                                required  
                                placeholder="Enter Project Size" 
                                :error="$errors->first('project_size')"
                                :min="0"
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the project size of the project." 
                            />
                         
                    </div>
                    @else
                    
                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        
                           

                            <x-ui.input 
                                id="lot_size"
                                name="lot_size"
                                type="number"
                                wire:model.live="lot_size"   
                                label="Lot size"
                                required  
                                placeholder="Enter Lot Size" 
                                :error="$errors->first('lot_size')"
                                :min="0"
                                displayTooltip
                                position="top"
                                tooltipText="Please enter the lot size of the project." 
                            />
                         

                    </div>
                    @endif


                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                         
                        <x-ui.select
                            id="unit_of_size"
                            name="unit_of_size"
                            label="Unit of Size"
                            wire:model.live="unit_of_size"
                            required="" 
                            placeholder="Select a unit" 
                            :error="$errors->first('unit_of_size')"
                            :options="$lot_size_unit_options"
  
                            displayTooltip
                            position="top"
                            tooltipText="Please enter the unit of size  "
 

                        />

                    </div>
                    

                    @if($type == "Federal Government" || $type == "Local Government")
                    <div class="space-y-2 col-span-12   ">
                        <x-ui.input 
                            id="agency"
                            name="agency"
                            type="text"
                            wire:model.live="agency"   
                            label="Agency"
                            required  
                            placeholder="Enter agency" 
                            :error="$errors->first('agency')"

                            displayTooltip
                            position="top"
                            tooltipText="Please enter the agency of the project." 
 
                        />


                    </div> 
                    @endif


                    @if($type == "Private")
                    <div class="space-y-2 col-span-12   ">
                        <x-ui.input 
                            id="company"
                            name="company"
                            type="text"
                            wire:model.live="company"   
                            label="Company"
                            required  
                            placeholder="Enter company" 
                            :error="$errors->first('company')"

                            displayTooltip
                            position="top"
                            tooltipText="Please enter the company of the project." 
 
                        /> 
                    </div> 
                    @endif


                    {{-- -

                    <div class="space-y-2 mt-1 col-span-12 sm:col-span-3  ">
                         
                        <x-ui.toggle
    

                            id="site_area_inspection"
                            name="site_area_inspection"
                            label="Site Area Inpection"
                            
                            onLabel="Yes"
                            offLabel="No" 
                            wire:model.live="site_area_inspection" 
                            :error="$errors->first('site_area_inspection')" 
  
                            displayTooltip
                            position="top"
                            tooltipText="Please confirm if there is Site Area Inspection" 
                        />


                    </div>

                    <div class="space-y-2 mt-1 col-span-12 sm:col-span-3  ">
                         
                        <x-ui.toggle
    

                            id="burials_discovered_onsite"
                            name="burials_discovered_onsite"
                            label="Burials Discovered Onsite"
                            
                            onLabel="Yes"
                            offLabel="No" 
                            wire:model.live="burials_discovered_onsite" 
                            :error="$errors->first('burials_discovered_onsite')" 
  
                            displayTooltip
                            position="top"
                            tooltipText="Please confirm if there is Burials Discovered Onsite" 
                        />


                    </div>

                    <div class="space-y-2 mt-1 col-span-12 sm:col-span-3  ">
                         
                        <x-ui.toggle
    

                            id="certificate_of_approval"
                            name="certificate_of_approval"
                            label="Certificate of Approval"
                            
                            onLabel="Yes"
                            offLabel="No" 
                            wire:model.live="certificate_of_approval" 
                            :error="$errors->first('certificate_of_approval')" 
  
                            displayTooltip
                            position="top"
                            tooltipText="Please confirm if there is Certificate of Approval" 
                        />


                    </div>

                    <div class="space-y-2 mt-1 col-span-12 sm:col-span-3  ">
                         
                        <x-ui.toggle
    

                            id="notice_of_violation"
                            name="notice_of_violation"
                            label="Notice of Violation"
                            
                            onLabel="Yes"
                            offLabel="No" 
                            wire:model.live="notice_of_violation" 
                            :error="$errors->first('notice_of_violation')" 
  
                            displayTooltip
                            position="top"
                            tooltipText="Please confirm if there is Notice of Violation" 
                        />


                    </div>




                    
 


                    <!-- Card -->
                    <section class="space-y-2 col-span-12  ">
                         <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Project Companies
                        </label> 
                        <div
                            x-data="{
                                companies: @entangle('companies').live,
                                add() {
                                    this.companies.push({ name: '' });
                                    this.$nextTick(() => {
                                        const i = this.companies.length - 1;
                                        document.getElementById('company-' + i)?.focus();
                                    });
                                },
                                remove(i) {
                                this.companies.splice(i, 1);
                                }
                            }"
                            class="space-y-2"
                            >
                            <template x-for="(company, i) in companies" :key="i">
                                <div class="flex items-center gap-2">
                                <label class="sr-only" :for="'company-' + i">Project Companies</label>

                                <input
                                    :id="'company-' + i"
                                    type="text"
                                    placeholder="e.g., Baseline Construction Corp."
                                    x-model="company.name"
                                    class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500"
                                />

                                <button type="button"
                                        @click="remove(i)"
                                        class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-4 w-4"> <path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18M8 6v-.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V6m-8 0h8m-9 0l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13M10 11v6m4-6v6" /> </svg>
                                </button>
                                </div>
                            </template>

                            <div>
                                <button type="button"
                                        @click="add()"
                                        class="inline-flex items-center rounded-lg bg-sky-600 px-3 py-2 text-sm font-semibold text-white hover:bg-sky-700">
                                <!-- plus icon -->
                                Add another company
                                </button>
                            </div>
                        </div>

 
                         
                    </section>

                    <!-- Card -->
                    <section class="space-y-2 col-span-12  ">
                         <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Federal Agencies
                        </label> 
                        <div
                            x-data="{
                                federal_agencies: @entangle('federal_agencies').live,
                                add() {
                                    this.federal_agencies.push({ name: '' });
                                    this.$nextTick(() => {
                                        const i = this.federal_agencies.length - 1;
                                        document.getElementById('company-' + i)?.focus();
                                    });
                                },
                                remove(i) {
                                this.federal_agencies.splice(i, 1);
                                }
                            }"
                            class="space-y-2"
                            >
                            <template x-for="(federal_agency, i) in federal_agencies" :key="i">
                                <div class="flex items-center gap-2">
                                <label class="sr-only" :for="'federal_agency-' + i">Project federal agencies</label>

                                <input
                                    :id="'federal_agency-' + i"
                                    type="text"
                                    placeholder="e.g., Dimensionsystem Agency."
                                    x-model="federal_agency.name"
                                    class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500"
                                />

                                <button type="button"
                                        @click="remove(i)"
                                        class="inline-flex items-center rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" class="h-4 w-4"> <path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18M8 6v-.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V6m-8 0h8m-9 0l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13M10 11v6m4-6v6" /> </svg>
                                </button>
                                </div>
                            </template>

                            <div>
                                <button type="button"
                                        @click="add()"
                                        class="inline-flex items-center rounded-lg bg-sky-600 px-3 py-2 text-sm font-semibold text-white hover:bg-sky-700">
                                <!-- plus icon -->
                                Add another federal_agency
                                </button>
                            </div>
                        </div>

 
                         
                    </section>


                     --}}

                    <div class="space-y-2 col-span-12   ">
                        {{-- <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Description
                        </label>

                        <textarea
                         autocomplete="description"
                        wire:model="description"
                        id="description"  class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""></textarea>

                        @error('description')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror --}}


                        <x-ui.textarea
                            id="description"
                            name="description"
                            label="Description"
                            wire:model.live="description"
                            required=""  
                            :error="$errors->first('description')" 
  
                            displayTooltip
                            position="top"
                            tooltipText="Please enter the project description  "
 

                        />




                    </div>
                    
                   


                </div> 
 
                
                <!-- Subscriber section --> 
                    <x-ui.user.subscriber-section
                        :users="$users"
                        :selectedUsers="$selectedUsers"
                        query="query"
                        removeAction="removeSubscriber"
                    />
                <!-- ./ Subscriber section --> 

                

                @if ($errors->any())
                         
                    @foreach ($errors->all() as $error) 


                        <div class="mt-2 bg-red-100 border border-red-200 text-sm text-red-800 rounded-lg p-4 " role="alert" tabindex="-1" aria-labelledby="hs-soft-color-danger-label">
                            <span id="hs-soft-color-danger-label" class="font-bold">Error: </span>
                            {{ $error }}
                        </div>


                    @endforeach 
                @endif 


                @if (session()->has('error'))
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 mt-5" role="alert">
                        {{ session('error') }}
                    </div>
                @endif


                <div class="mt-5 flex justify-center gap-x-2">



                    <livewire:partials.projects.page-cancel-button text="Cancel" />



                    <button type="button" 
                        {{-- onclick="confirm('Are you sure you want to save this project with the project attachments? Project attachments cannot be deleted after adding it.?') || event.stopImmediatePropagation()" --}}
                        onclick="confirm('Are you sure you want to save this project?') || event.stopImmediatePropagation()" 
                        wire:click.prevent="save()"
                        class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                        Save
                    </button>

                    {{-- @if( Auth::user()->can('system access global admin') || Auth::user()->can('project submit') )
                        <button  type="button"
                            onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
                            wire:click.prevent="submit_project()"
                            
                            class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                            Submit
                        </button> 
                    @endif --}}
                </div>
            </div>
        </div>
        <!-- End Card -->
    </form>
 

    <aside class="col-span-12   mt-4 ">
        <div class="bg-white rounded-xl shadow-sm border">
            
        </div>
    </aside>

 
{{-- - 
<div x-data="{ open:false }" x-id="['subscribers-modal']" class="relative">
  <!-- Launcher -->
  <button
    type="button"
    @click="open = true; $nextTick(() => $refs.first?.focus())"
    class="inline-flex items-center rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
  >
    Add Subscribers
  </button>

  <!-- Modal (overlay + panel) -->
  <div
    x-show="open"
    x-transition.opacity
    class="fixed inset-0 z-[60] flex items-center justify-center"
    role="dialog"
    :aria-labelledby="$id('subscribers-modal')"
    aria-modal="true"
  >
    <!-- Overlay -->
    <div class="absolute inset-0 bg-slate-900/50" @click="open = false"></div>

    <!-- Panel -->
    <div
      x-show="open"
      x-transition.scale.origin.center
      @keydown.escape.window="open = false"
      class="relative z-[61] w-full max-w-5xl max-h-[90vh] overflow-auto rounded-2xl bg-white shadow-xl"
    >
      <!-- Modal header -->
      <div class="flex items-center justify-between border-b px-5 py-3">
        <h2 :id="$id('subscribers-modal')" class="text-base font-semibold text-slate-900">
          Project Subscribers
        </h2>
        <button
          type="button"
          @click="open = false"
          class="rounded-md p-1.5 text-slate-500 hover:bg-slate-100"
          aria-label="Close"
        >
          <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      </div>

      <!-- Modal body: paste your Tailwind form here -->
      <div class="p-5">
        <!-- 👇 Your existing Tailwind form goes here (unchanged). Example: -->
        <section class="max-w-5xl mx-auto">
          


            <!-- Project Subscribers – Tailwind UI (markup only) -->
            <section class="max-w-5xl mx-auto p-4 sm:p-6">
            <!-- Card -->
            <div class="rounded-2xl border bg-white shadow-sm">
                <!-- Header -->
                <div class="flex items-center justify-between px-5 py-4 border-b">
                <div class="flex items-center gap-3">
                    <span class="inline-flex h-7 w-7 items-center justify-center rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold">SB</span>
                    <div>
                    <h2 class="text-sm font-semibold text-slate-900">Project Subscribers</h2>
                    <p class="text-xs text-slate-500">Add teammates or invite by email. Configure who gets notified.</p>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <label for="default_role" class="sr-only">Default role</label>
                    <select id="default_role" class="rounded-lg border-slate-300 text-sm focus:ring-emerald-500 focus:border-emerald-500">
                    <option>Watcher</option>
                    <option>Collaborator</option>
                    <option>Reviewer</option>
                    <option>Owner</option>
                    </select>
                    <button type="button" class="inline-flex items-center rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
                    <!-- Check icon -->
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    Save
                    </button>
                </div>
                </div>

                <!-- Body -->
                <div class="p-5 space-y-6">
                <!-- Add by search / Invite by email -->
                <div class="grid sm:grid-cols-2 gap-3">
                    <!-- Search users -->
                    <div>
                    <label class="block text-sm font-medium text-slate-700">Search users</label>
                    <div class="relative mt-1">
                        <input type="text" placeholder="Type a name or email…" class="w-full rounded-lg border-slate-300 focus:ring-emerald-500 focus:border-emerald-500 pr-9">
                        <svg class="absolute right-2 top-2.5 w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M10 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z"/></svg>
                    </div>

                    <!-- Example dropdown (static markup) -->
                    <ul class="mt-2 rounded-xl border bg-white divide-y max-h-64 overflow-auto">
                        <li class="flex items-center justify-between px-3 py-2 hover:bg-slate-50">
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-slate-900 truncate">John Doe</p>
                            <p class="text-xs text-slate-500 truncate">john@example.com</p>
                        </div>
                        <button type="button" class="inline-flex items-center rounded-md border px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Add</button>
                        </li>
                        <li class="flex items-center justify-between px-3 py-2 hover:bg-slate-50">
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-slate-900 truncate">Jane Smith</p>
                            <p class="text-xs text-slate-500 truncate">jane@example.com</p>
                        </div>
                        <button type="button" class="inline-flex items-center rounded-md border px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Add</button>
                        </li>
                    </ul>
                    <!-- /Example dropdown -->
                    </div>

                    <!-- Invite by email -->
                    <div>
                    <label class="block text-sm font-medium text-slate-700">Invite by email</label>
                    <div class="mt-1 flex gap-2">
                        <input type="email" placeholder="name@domain.com" class="w-full rounded-lg border-slate-300 focus:ring-emerald-500 focus:border-emerald-500">
                        <button type="button" class="inline-flex items-center rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-800">Invite</button>
                    </div>
                    <!-- Example validation -->
                    <!-- <p class="text-xs text-red-600 mt-1">Please enter a valid email address.</p> -->
                    </div>
                </div>

                <!-- Selected (staged) -->
                <div>
                    <h3 class="text-sm font-semibold text-slate-900 mb-2">Selected</h3>

                    <!-- Empty state -->
                    <!-- <p class="text-xs text-slate-500">No subscribers yet. Search or invite to add them here.</p> -->

                    <!-- Example staged item -->
                    <ul class="space-y-2">
                    <li class="flex flex-col sm:flex-row sm:items-center gap-3 justify-between rounded-xl border px-3 py-2 bg-slate-50">
                        <div class="min-w-0">
                        <p class="text-sm font-medium text-slate-900 truncate">John Doe</p>
                        <p class="text-xs text-slate-500 truncate">
                            john@example.com
                            <span class="ml-1 inline-block text-[10px] px-1.5 py-0.5 rounded bg-white border">USER</span>
                        </p>
                        </div>

                        <div class="flex flex-wrap items-center gap-2">
                        <select class="rounded-md border-slate-300 text-xs focus:ring-emerald-500 focus:border-emerald-500">
                            <option>Watcher</option>
                            <option>Collaborator</option>
                            <option selected>Reviewer</option>
                            <option>Owner</option>
                        </select>

                        <!-- Notification toggles (static) -->
                        <div class="flex items-center gap-1 text-xs">
                            <button type="button" class="px-2 py-1 rounded-md border bg-white ring-1 ring-emerald-500">All</button>
                            <button type="button" class="px-2 py-1 rounded-md border bg-white ring-1 ring-emerald-500">Docs</button>
                            <button type="button" class="px-2 py-1 rounded-md border bg-white">Comments</button>
                            <button type="button" class="px-2 py-1 rounded-md border bg-white">Reviews</button>
                        </div>

                        <button type="button" class="inline-flex items-center rounded-md bg-white border px-2 py-1 text-xs text-slate-700 hover:bg-slate-50">
                            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                            Remove
                        </button>
                        </div>
                    </li>

                    <!-- Duplicate the <li> above for more staged items -->
                    </ul>
                </div>
                </div>
            </div>

            <!-- Current subscribers (read-only snapshot) -->
            <div class="mt-4 rounded-2xl border bg-white">
                <div class="px-5 py-3 border-b flex items-center justify-between">
                <h3 class="text-sm font-semibold text-slate-900">Current Subscribers</h3>
                <span class="text-xs text-slate-500">Read-only snapshot</span>
                </div>
                <div class="divide-y">
                <!-- Repeat row -->
                <div class="px-5 py-3 flex items-center justify-between">
                    <div class="min-w-0">
                    <p class="text-sm font-medium text-slate-900 truncate">john@example.com</p>
                    <p class="text-xs text-slate-500">Role: Reviewer</p>
                    </div>
                    <div class="text-xs text-slate-500 space-x-1">
                    <span class="inline-block px-1.5 py-0.5 rounded border">All</span>
                    <!-- or granular:
                    <span class="inline-block px-1.5 py-0.5 rounded border">Docs</span>
                    <span class="inline-block px-1.5 py-0.5 rounded border">Comments</span>
                    <span class="inline-block px-1.5 py-0.5 rounded border">Reviews</span>
                    -->
                    </div>
                </div>

                <div class="px-5 py-3 flex items-center justify-between">
                    <div class="min-w-0">
                    <p class="text-sm font-medium text-slate-900 truncate">jane@example.com</p>
                    <p class="text-xs text-slate-500">Role: Watcher</p>
                    </div>
                    <div class="text-xs text-slate-500 space-x-1">
                    <span class="inline-block px-1.5 py-0.5 rounded border">Docs</span>
                    <span class="inline-block px-1.5 py-0.5 rounded border">Comments</span>
                    <span class="inline-block px-1.5 py-0.5 rounded border">Reviews</span>
                    </div>
                </div>
                <!-- /Repeat row -->
                </div>
            </div>
            </section>




        </section>
      </div>

      <!-- Modal footer -->
      <div class="flex items-center justify-end gap-2 border-t px-5 py-3">
        <button
          type="button"
          class="rounded-lg border px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          @click="open = false"
        >Close</button>
        <button
          type="button"
          class="inline-flex items-center rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          Save
        </button>
      </div>
    </div>
  </div>
</div>
--}}

 
    <!--  Loaders -->
         

        {{-- wire:target="save"   --}}
        <div wire:loading  wire:target="save"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Saving record...
                    </div>
                </div>
            </div>

            
        </div>


        {{-- wire:target="location"   --}}
        {{-- <div wire:loading  wire:target="location"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Loading Location...
                    </div>
                </div>
            </div>

            
        </div> --}}



    <!--  ./ Loaders -->
    

</div>
<!-- End Card Section -->

<!-- Card Section -->
<div id="project-wrapper" data-project-id="{{ $project->id ?? null }}" class="max-w-[85rem] px-4 py-6 sm:px-6 lg:px-8  mx-auto grid grid-cols-12 gap-x-2">
    {{-- The whole world belongs to you. --}}
    {{-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places"></script>
     --}}

    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA70BOfcc1ELmwAEmY-rFNkbNauIXT79cA&libraries=places&callback=initMap"
        async
        defer>
    </script>

     
    {{-- <div wire:loading class="loading-overlay"> --}}
        {{-- <div wire:loading style="color: #64d6e2" class="la-ball-clip-rotate-pulse la-3x preloader">
            <div></div>
            <div></div>
        </div> --}}
    {{-- </div> --}}
    

    <form class="col-span-12  lg:col-span-10" wire:submit="save">
        <!-- Card -->
        <div class="bg-white rounded-xl shadow ">


            <div class="  p-4">

                <div class="sm:col-span-12">
                    <h2 class="text-lg font-semibold text-gray-800 ">
                        Submit new project
                    </h2>
                </div>
                <!-- End Col -->


                @if(!empty($project_location_bypass) && $project_location_bypass->value == "ACTIVE")
                <!-- display nothing -->
                @else
                <div class="grid grid-cols-12 gap-x-2  ">

                    <div class="space-y-2 col-span-12 my-1  ">
                        <h2>Search and Save Location</h2>
                        {{-- <input type="text" id="search-box"  wire:model="location"> --}}
                        {{-- <input type="text" id="search-box" placeholder="Search location" wire:model="location"> --}}
    
     
                        {{-- <input
                        autofocus autocomplete="location"
                        wire:model="location"
                        readonly placeholder="Search location"
                        id="search-box" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm text-gray-500 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""> --}}

                        
                        <input
                        autofocus autocomplete="location"
                        wire:model="location"
                          placeholder="Search location"
                        id="search-box" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

    
                        <input type="hidden" id="latitude" wire:model.live="latitude">
                        <input type="hidden" id="longitude" wire:model.live="longitude">


                         
                    </div>
                    <div class="space-y-2 col-span-12    ">
                        <div>
                            
                            <div id="map" style="height: 500px; width: 100%;" wire:ignore></div>
                        {{-- <button wire:click="saveLocation">Save Location</button> --}}
                        </div>


                        <div>
                            @error('location')
                                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                            @enderror

                            @error('latitude')
                                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                            @enderror

                            @error('longitude')
                                <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>





                </div>
                @endif

 
                



                <!-- Grid -->
                <div class="grid grid-cols-12 gap-x-2  ">

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Name
                        </label>

                        <input
                        autofocus autocomplete="name"
                        wire:model="name"
                        id="name" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('name')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="federal_agency" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Company
                        </label>

                        <input
                        autofocus autocomplete="federal_agency"
                        wire:model="federal_agency"
                        id="federal_agency" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('federal_agency')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>


                    <div class="space-y-2 col-span-12 sm:col-span-4  ">
                        <label for="type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Type
                        </label>


                        <select
                        autocomplete="type"
                        wire:model="type"
                        id="type"
                        class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  ">
                            <option selected="">Select type</option>

                            @if(!empty($project_types))
                                @foreach ($project_types as $type_id => $type_name )
                                    <option>{{ $type_name }}</option> 
                                @endforeach 
                            @endif
                        </select>

                        {{-- <input
                        autofocus autocomplete="type"
                        wire:model="type"
                        id="type" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""> --}}

                        @error('type')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>






                    <div class="space-y-2 col-span-12   ">
                        <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Description
                        </label>

                        <textarea
                        autofocus autocomplete="description"
                        wire:model="description"
                        id="description"  class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder=""></textarea>

                        @error('description')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>
                    
                  

                    <!-- project document -->   
                        <!-- project document permission is required first -->
                        @if(Auth::user()->can('system access global admin') || Auth::user()->can('project document create')  )
                            <div class="space-y-2 col-span-12     ">

                                <div class="space-y-2 col-span-12 sm:col-span-4  ">
                                    <label for="type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                                        Add Document Type 
                                    </label>
                                    <select
                                        class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  "
                                        wire:model.live="document_type_id"
                                        
                                        >
                                        <option value="">Select Document Type</option>
                                        @foreach($documentTypes as $type)
                                            <option value="{{ $type->id }}">{{ $type->name }}</option>
                                        @endforeach 

                                    </select>


                                    @error('document_type_id')
                                        <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                                    @enderror 
                                    
                                </div>


                                @if(Auth::user()->can('system access global admin') || Auth::user()->can('project add attachment') )

                                    <label for="description" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                                        Document Attachments
                                    </label>

                                    <livewire:dropzone
                                        wire:model="attachments"
                                        :rules="['file', 'mimes:png,jpeg,jpg,pdf,docx,xlsx,csv,txt,zip', 'max:20480']"
                                        :multiple="true" />


                                    @error('attachments')
                                        <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                                    @enderror 

                                @endif

                            </div>
                        @endif
                    <!-- ./ project document -->



                </div> 


                <!-- section visible to admin only -->
                {{-- @if( Auth::user()->can('system access global admin') && Auth::user()->hasPermissionTo('timer edit') )  --}}
                <!-- Timer -->
                <div class="grid grid-cols-12 gap-x-2  
                {{ ( Auth::user()->can('system access global admin') || Auth::user()->hasRole('system access reviewer') )  ? 'block' : 'hidden'}}
                ">

                    <div class="space-y-2 col-span-12 sm:col-span-3  ">
                        <label for="submitter_response_duration" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Submitter duration
                        </label>

                        <input
                        min="1"
                        autofocus autocomplete="submitter_response_duration"
                        wire:model.live="submitter_response_duration"
                         
                        id="submitter_response_duration" type="number" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('submitter_response_duration')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-3  ">
                        <label for="submitter_response_duration_type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Submitter duration type
                        </label>

                        <select 
                         
                        autofocus autocomplete="submitter_response_duration_type"
                        wire:model.live="submitter_response_duration_type"
                        id="submitter_response_duration_type" 
                        class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  ">
                            <option selected="">Select type</option>
                            <option value="day">Day</option>
                            <option value="week">Week</option>
                            <option value="month">Month</option>
                        </select>

                        @error('submitter_response_duration_type')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-6  ">
                        <label for="submitter_due_date" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Submitter response due date
                        </label>

                        <input readonly 
                        {{-- autofocus autocomplete="submitter_due_date"
                        wire:model.live="submitter_due_date" --}}
                        value="{{ \Carbon\Carbon::parse($submitter_due_date)->format('d M, h:i A') }}"
                        id="submitter_due_date" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('submitter_due_date')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                </div>

                <!-- Recieved time or response is determined by the submitted -->
                <div class="grid grid-cols-12 gap-x-2  
                {{ ( Auth::user()->can('system access global admin')  || Auth::user()->hasRole('system access reviewer') 

                )  ? 'block' : 'hidden'
                
                
                }}
                ">

                    <div class="space-y-2 col-span-12 sm:col-span-3  ">
                        <label for="reviewer_response_duration" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Reviewer duration
                        </label>

                        <input
                        min="1"
                        autofocus autocomplete="reviewer_response_duration"
                        wire:model.live="reviewer_response_duration"
                        id="reviewer_response_duration" type="number" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('reviewer_response_duration')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    <div class="space-y-2 col-span-12 sm:col-span-3  ">
                        <label for="reviewer_response_duration_type" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Reviewer duration type
                        </label>

                        <select 
                        autofocus autocomplete="reviewer_response_duration_type"
                        wire:model.live="reviewer_response_duration_type"
                        id="reviewer_response_duration_type" 
                        class="py-2 px-3 pe-11  block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  ">
                            <option selected="">Select type</option>
                            <option value="day">Day</option>
                            <option value="week">Week</option>
                            <option value="month">Month</option>
                        </select>

                        @error('reviewer_response_duration_type')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>


                    


                    <div class="space-y-2 col-span-12 sm:col-span-6  ">
                        <label for="reviewer_due_date" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                            Reviewer response due date
                        </label>

                        <input readonly 
                        {{-- autocomplete="reviewer_due_date"
                        wire:model.live="reviewer_due_date" --}}    
                        value="{{ \Carbon\Carbon::parse($reviewer_due_date)->format('d M, h:i A') }}"
                        id="reviewer_due_date" type="text" class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  " placeholder="">

                        @error('reviewer_due_date')
                            <p class="text-sm text-red-600 mt-2">{{ $message }}</p>
                        @enderror


                    </div>

                    
                    
                    @if(!empty($project_timer))
                    <p class="text-sm text-gray-500 mt-2 col-span-12"> 
                        Updated {{  \Carbon\Carbon::parse($project_timer->updated_at)->format('d M, h:i A') }} by {{ $project_timer->updator ? $project_timer->updator->name : '' }}
                                            
                    </p>

                    @else
                    <p class="text-sm text-gray-500 mt-2 col-span-12"> 
                        Project timers are set to default and haven't been updated.                   
                    </p>
                    @endif


                </div>
                <!-- End Timer -->
                {{-- @endif --}}


                <!-- -->

                @if(Auth::user()->hasRole('User')) 
                <!-- End Grid -->
                <p class="text-sm text-gray-600 mt-2">{{ !empty($reviewer_due_date) ? 'Expect to get a review at '.\Carbon\Carbon::parse($reviewer_due_date)->format('d M, h:i A') : '' }}</p>
                @endif

                @if ($errors->any())
                         
                    @foreach ($errors->all() as $error) 


                        <div class="mt-2 bg-red-100 border border-red-200 text-sm text-red-800 rounded-lg p-4 " role="alert" tabindex="-1" aria-labelledby="hs-soft-color-danger-label">
                            <span id="hs-soft-color-danger-label" class="font-bold">Error: </span>
                            {{ $error }}
                        </div>


                    @endforeach 
                @endif 


                @if (session()->has('error'))
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 mt-5" role="alert">
                        {{ session('error') }}
                    </div>
                @endif


                <div class="mt-5 flex justify-center gap-x-2">
                    <a href="{{ route('project.index') }}" class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:bg-red-700 disabled:opacity-50 disabled:pointer-events-none">
                        Cancel
                    </a>
                    <button type="button" 
                        onclick="confirm('Are you sure you want to save this project with the project attachments? Project attachments cannot be deleted after adding it.?') || event.stopImmediatePropagation()"
                        wire:click.prevent="save()"
                        class="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                        Save
                    </button>

                    {{-- @if( Auth::user()->can('system access global admin') || Auth::user()->can('project submit') )
                        <button  type="button"
                            onclick="confirm('Are you sure, you want to submit this project?') || event.stopImmediatePropagation()"
                            wire:click.prevent="submit_project()"
                            
                            class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-transparent bg-sky-600 text-white hover:bg-sky-700 focus:outline-none focus:bg-sky-700 disabled:opacity-50 disabled:pointer-events-none">
                            Submit
                        </button> 
                    @endif --}}
                </div>
            </div>
        </div>
        <!-- End Card -->
    </form>

    {{-- <aside class="col-span-12 lg:col-span-2 mt-2 md:mt-0">
        <div class="bg-white rounded-xl shadow  ">
            <div class="  p-4">

                <div class="sm:col-span-12">
                    <h2 class="text-lg font-semibold text-gray-800 ">
                        Project Subscribers  
                    </h2>
                    <p class="text-gray-500 text-xs">Users that will be notified on project updates</p>
                </div> 

                <label for="name" class="inline-block text-sm font-medium text-gray-800 mt-2.5 ">
                    Search for User Name
                </label>

                <input type="text" wire:model.live="query" placeholder="Type to search..." class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none  ">
                
                <!-- Search Results Dropdown -->
                @if(!empty($users))
                    <ul class="border rounded mt-2 bg-white w-full max-h-48 overflow-auto">
                        @foreach($users as $user)
                            <li wire:click="addSubscriber({{ $user->id }})" class="p-2 cursor-pointer hover:bg-gray-200">
                                {{ $user->name }}
                            </li>
                        @endforeach
                    </ul>
                @endif
            
                <!-- Selected Subscribers -->
                <div class="mt-4">
                    <h3 class="font-bold">Selected Subscribers:</h3>
                    
                    @if(!empty($selectedUsers))
                        <ul>
                            @foreach($selectedUsers as $index => $user)
                                <li class="flex items-center justify-between bg-gray-100 p-2 rounded mt-1 text-truncate">
                                    <span>{{ $user['name'] }}</span>
                                    <button wire:click="removeSubscriber({{ $index }})" class="text-red-500">❌</button>
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <p class="text-gray-500">No subscribers selected.</p>
                    @endif
                </div>

            </div>

        </div>
    </aside> --}}

    <aside class="col-span-12 lg:col-span-2 mt-4 lg:mt-0">
        <div class="bg-white rounded-xl shadow-sm border">
            <div class="p-4 space-y-4">

                <!-- Header -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800">
                        Project Subscribers
                    </h2>
                    <p class="text-sm text-gray-500">
                        Users that will be notified on project updates.
                    </p>
                </div>

                <!-- Search -->
                <div>
                    <label for="subscriber-search" class="block text-sm font-medium text-gray-700">
                        Search for User Name
                    </label>
                    <div class="relative mt-1">
                        <input id="subscriber-search"
                            type="text"
                            wire:model.live="query"
                            placeholder="Type to search..."
                            class="block w-full rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm px-3 py-2"
                        >
                    </div>
                </div>

                <!-- Search Results -->
                @if(!empty($users))
                    <ul class="border rounded-md mt-2 bg-white shadow-sm max-h-48 overflow-auto divide-y divide-gray-100">
                        @foreach($users as $user)
                            <li wire:click="addSubscriber({{ $user->id }})"
                                class="px-4 py-2 cursor-pointer hover:bg-sky-50 transition text-sm">
                                {{ $user->name }}
                            </li>
                        @endforeach
                    </ul>
                @endif

                <!-- Selected Subscribers -->
                <div>
                    <h3 class="text-sm font-semibold text-gray-700 mb-1">
                        Selected Subscribers
                    </h3>

                    @if(!empty($selectedUsers))
                        <ul class="space-y-1">
                            @foreach($selectedUsers as $index => $user)
                                <li class="flex items-center justify-between bg-sky-50 px-3 py-2 rounded-md text-sm text-sky-800 border border-sky-100">
                                    <span class="truncate">{{ $user['name'] }}</span>
                                    <button wire:click="removeSubscriber({{ $index }})"
                                            class="ml-2 text-red-500 hover:text-red-600 focus:outline-none"
                                            title="Remove">
                                        ✕
                                    </button>
                                </li>
                            @endforeach
                        </ul>
                    @else
                        <p class="text-sm text-gray-400">No subscribers selected.</p>
                    @endif
                </div>
            </div>
        </div>
    </aside>


    <script>
        let map, marker, searchBox;

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: 13.4443, lng: 144.7937 }, // Centered on Guam
                zoom: 11,
                // mapTypeId: google.maps.MapTypeId.SATELLITE // ✅ Default to Satellite view
            });

            marker = new google.maps.Marker({
                position: map.getCenter(),
                map: map,
                draggable: true
            });

            const input = document.getElementById("search-box");
            searchBox = new google.maps.places.SearchBox(input);
            // map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

            // searchBox.addListener("places_changed", function () {
            //     let places = searchBox.getPlaces();
            //     if (places.length == 0) return;

            //     let place = places[0];
            //     map.setCenter(place.geometry.location);
            //     marker.setPosition(place.geometry.location);


            //     @this.set('latitude', place.geometry.location.lat());
            //     @this.set('longitude', place.geometry.location.lng());
            //     @this.set('location', place.name);

                 

            // });

            searchBox.addListener("places_changed", function () {
                let places = searchBox.getPlaces();
                if (places.length == 0) return;

                let place = places[0];
                map.setCenter(place.geometry.location);
                marker.setPosition(place.geometry.location);

                let fullAddress = place.formatted_address || place.name; // Use full address if available

                @this.set('latitude', place.geometry.location.lat());
                @this.set('longitude', place.geometry.location.lng());
                @this.set('location', fullAddress); // ✅ Use full address instead of just name

                console.log("Updated Location:", fullAddress);
            });

            const geocoder = new google.maps.Geocoder();

            marker.addListener("dragend", function () {
                let lat = marker.getPosition().lat();
                let lng = marker.getPosition().lng();

                // Reverse geocode to get location name
                geocoder.geocode({ location: { lat, lng } }, function (results, status) {
                    if (status === "OK" && results[0]) {
                        let locationName = results[0].formatted_address;

                        // Send data to Livewire
                        @this.set('latitude', lat);
                        @this.set('longitude', lng);
                        @this.set('location', locationName);

                        console.log("Updated Location:", locationName);
                    } else {
                        console.error("Geocoder failed: " + status);
                    }
                });
            });
        }

        window.onload = initMap;

         
    </script>


    <!--  Loaders -->
         

        {{-- wire:target="save"   --}}
        <div wire:loading  wire:target="save"
        
        >
            <div class="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center transition-opacity duration-300">
                <div class="bg-gray-900 text-white px-6 py-5 rounded-xl shadow-xl flex items-center gap-4 animate-pulse w-[320px] max-w-full text-center">
                    <svg class="h-6 w-6 animate-spin text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <div class="text-sm font-medium">
                        Saving record...
                    </div>
                </div>
            </div>

            
        </div>
    <!--  ./ Loaders -->
    

</div>
<!-- End Card Section -->
